/**
 * @description       :
 * @author            : Stefanie Elling
 * @group             :
 * @last modified on  : 10-14-2022
 * @last modified by  : Dilvar Singh
 **/
import { LightningElement, api, track, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import communityId from '@salesforce/community/Id';
import productSearch from '@salesforce/apex/LB2BSearchPLPController.productSearch';
// import productTagSearch from '@salesforce/apex/LB2BSearchPLPController.productTagSearch';
// import productStockAvailabilty from '@salesforce/apex/LB2BSearchPLPController.productStockAvailabilty';
// import producttags2 from '@salesforce/apex/LB2BPlpStockAvailabilityController.productTagSearch';
// import productGppSearch from '@salesforce/apex/LB2BSearchPLPController.productGppSearch';
import getCartSummary from '@salesforce/apex/LB2BCartController.getCartSummary';
import { transformData } from './dataNormalizer';
import LB2BLoadingProducts from '@salesforce/label/c.LB2BLoadingProductsPLP';
import LB2BClearAll from '@salesforce/label/c.LB2BClearAll';
import LB2BFiltersPLP from '@salesforce/label/c.LB2BFiltersPLP';
import LB2BItems from '@salesforce/label/c.LB2BItems';
import LB2BOf from '@salesforce/label/c.LB2BOf';
import LB2BOneResult from '@salesforce/label/c.LB2BOneResult';
import COMMUNITY_ID from '@salesforce/community/Id';
import LANG from '@salesforce/i18n/lang';
import LOCALE from '@salesforce/i18n/locale';
import getBreadcrumbs from '@salesforce/apex/LB2BBreadcrumbsController.getBreadcrumbs';
import communityBasePath from '@salesforce/community/basePath';
import { CurrentPageReference } from 'lightning/navigation';
import {SearchResultsEvent} from 'c/lb2bDataLayer';
import {NullSearchResultsEvent} from 'c/lb2bDataLayer';
import {NavigationEvent} from 'c/lb2bDataLayer';   //added
import getProducts from '@salesforce/apex/LB2BFeaturedProductsController.getFeaturedProducts';

/**
 * A search resutls component that shows results of a product search or
 * category browsing.This component handles data retrieval and management, as
 * well as projection for internal display components.
 * When deployed, it is available in the Builder under Custom Components as
 * 'B2B Custom Search Results'
 */
export default class lb2bSearchResults extends NavigationMixin(LightningElement) {
    /**
     * @typedef BreadcrumbWrapper
     *
     * @property {string} name
     * @property {string} categoryId
     */

    /**@type {Array<BreadcrumbWrapper>} */
    breadcrumbData = [];
    communityId = COMMUNITY_ID;

    @api
    pageSize;

    @api
    promoSpot;

    promotionList = [];

    /**
     * Gets the effective account - if any - of the user viewing the product.
     *
     * @type {string}
     */
    @api
    get effectiveAccountId() {
        return this._effectiveAccountId;
    }

    /**
     * Sets the effective account - if any - of the user viewing the product
     * and fetches updated cart information
     */
    set effectiveAccountId(newId) {
        this._effectiveAccountId = newId;
        this.updateCartInformation();
    }

    get isMobileScreen() {
        return window.innerWidth < 481;
    }

    /**
     *  Gets or sets the unique identifier of a category.
     *
     * @type {string}
     */
    @api
    get recordId() {
        return this._recordId;
    }
    set recordId(value) {
        this._recordId = value;
        this._landingRecordId = value;
    }

    pushData = false;
    _isNavigationSearch = false;
    inputData = []; //added

    /**
     *  Gets or sets the search term.
     *
     * @type {string}
     */
    @api
    get term() {
        return this._term;
    }
    set term(value) {
        this._term = value;
        if (value) {
            this.pushData = true;
                this.triggerProductSearch();
            } else {
                this._isNavigationSearch = true;
            }
        }

    @track
    _isSortRuleId;

    @api 
    indexVal = 0;

    labels = {
        LB2BLoadingProducts,
        LB2BClearAll,
        LB2BFiltersPLP,
        LB2BItems,
        LB2BOf,
        LB2BOneResult
    };

    prodIds = [];
    prodGppValues = [];
    metaDataValues;
    productTagValues;
    productStock;
    productIds= [];
    productstokIds = [];
    @track mapData= [];

    /**
     * @type {ConnectApi.ProductSummaryPage}
     * @private
     */
    triggerProductSearch() {
        this._isLoading = true;

        let refinementList = [];

        // Replace history record
        let state = {};
        if (history.state) {
            state = { ...history.state };
        }
        state.pageNumber = this._pageNumber;
        state.refinements = JSON.stringify(this._refinements);
        state.term = this.term;
        state.sort = this._isSortRuleId;
        console.log('State being written:', state);
        history.replaceState(state, '');

        for (let facet of this._refinements) {
            let substring = facet.attributeType + ',' + facet.nameOrId + ',' + facet.type + ':';
            if (facet.values && facet.values.length > 0) {
                for (let facetValue of facet.values) {
                    substring += facetValue + ';';
                }
            }
            substring = substring.substring(0, substring.length - 1);

            refinementList.push(substring);
        }

        const stringifiedWrapper = JSON.stringify({
            communityId: communityId,
            effectiveAccountId: this.resolvedEffectiveAccountId,
            locale: LOCALE,
            language: LANG,
            pageNumber: this._pageNumber - 1,
            pageSize: this.pageSize || 30,
            searchQuery: this.term,
            categoryId: this.recordId,
            sortOption: this._isSortRuleId,
            facets: refinementList
        });

        console.log('Search wrapper:', stringifiedWrapper);

        productSearch({
            inputString: stringifiedWrapper
        }).then((result) => {
            if (result.hasError) {
                console.error(result.errorMessage);
                this._isLoading = false;
                return;
            }
            
            this.promotionList = result.promos;
            // this.productsResult = result.products;  
            this.productStock = result.productStockAvailability;
            console.log('Products :', result);

            var result222 = Object.entries(this.productStock);
            console.log('result222>>',result222);
    
            // let objres = Object.keys(this.productStock);
            // console.log('objres',objres);
           
            // const keys = Array.from(result.productStockAvailability.keys());
            // const values = Array.from(result.productStockAvailability.values());
           // this.productstokIds =  this.productStock.keySet();
           // console.log(this.productstokIds);
           // const arr = [...result.productStockAvailability].map(([name, value]) => ({ name, value }));
            //console.log('arr',values,'dsd',keys);
         // console.log('dadsd',this.productStock.size);
            for(let i=0 ; i < result222.length; i++){
                for(let j=0 ; j< result.products.productsPage.products.length; j++){
                    console.log('Ids >>' ,result222[i][0],'++',result.products.productsPage.products[j].id);
                  if(result222[i][0] == result.products.productsPage.products[j].id ){
                    result.products.productsPage.products[j].stock = result222[i][1];
                    console.log('stkavb',result.products.productsPage.products[j]);
                  }
                }
    
            }
           // this.productsResult = result.products;
             this.displayData = result.products;
            //product availability status code starts
            

            
            console.log('Products :', this.displayData);

            console.log('this.productStock >>>',this.productStock);

            console.log('productIds',this.productIds);
                      
                       
            console.log('this.productStockFinal >>>',this.displayData);
   
            //product availability status code ends

            console.log('Promotions:', result.promos);
            this._isLoading = false;

            // data layer start
            if (this.displayData.total == 0) {
                if (this.pushData) {
                    this.MoveToDataLayer();
                    this.pushData = false;
                }
            }
            if (this.displayData.total > 0) {
                if (this.pushData) {
                    this.PushDatatoDataLayer();
                    NavigationEvent('navigation_click', 'search bar', 'site search');
                    this.pushData = false;
                }
            }
            
            //data alayer ends

            getBreadcrumbs({
                communityId: this.communityId,
                categoryId: this.recordId
            })
                .then((result) => {
                    this.breadcrumbData = result.breadcrumbList;
                        
                    //navigation data layer 
                    if (this.displayData.total > 0) {
                        console.log('this.breadcrumbData: ', this.breadcrumbData)
                        if (this.breadcrumbData != undefined) {
                            if (this.breadcrumbData.length > 1) {
                                if (this._isNavigationSearch) {
                                    //send the full hierarchy click  
                                    for (let i = 0; i < this.breadcrumbData.length; i++) {
                                        this.inputData.push(this.breadcrumbData[i].name);
                                    }
                                    let mergecategory = this.inputData.join(" - ");
                                    this.MoveDataToDataLayer(mergecategory);  //added
                                    this._isNavigationSearch = false;
                                }
                            }
                        }
                    }
                })
                .catch((error) => {
                    console.error('An error occurred getting breadcrumbs', error);
                });
        })
            .catch((error) => {
                console.log('api error',
                    this._recordId,
                    this.term,
                    this._isSortRuleId,
                    this._pageNumber,
                    this.communityId,
                    this.resolvedEffectiveAccountId
                );
                this.error = error;
                this._isLoading = false;
                console.error(error);
            });
            
    }

    get hasResults() {
        if (this._isLoading) {
            return true;
        } else {
            return this.displayData.total > 0;
        }
    }

    /**
     * Gets or sets the normalized, displayable results for use by the display components.
     *
     * @private
     */
    get displayData() {
        return this._displayData || {};
    }
    set displayData(data) {
        this._displayData = transformData(data, this.indexVal);

        if (this.promotionList && this.promotionList.length === 1) {
            this._displayData.layoutData.splice((this.promoSpot || 6) - 1, 0, {
                ...this.promotionList[0],
                isPromotion: true
            });
        }
    }

    /**
     * Gets whether product search is executing and waiting for result.
     *
     * @type {Boolean}
     * @readonly
     * @private
     */
    get isLoading() {
        return this._isLoading;
    }

    /**
     * Gets whether results has more than 1 page.
     *
     * @type {Boolean}
     * @readonly
     * @private
     */
    get hasMorePages() {
        return this.displayData.total > this.displayData.pageSize;
    }

    /**
     * Gets the current page number.
     *
     * @type {Number}
     * @readonly
     * @private
     */
    get pageNumber() {
        return this._pageNumber;
    }

    /**
     * Gets the header text which shows the search results details.
     *
     * @type {string}
     * @readonly
     * @private
     */
    get headerText() {
        let text = '';
        const totalItemCount = this.displayData.total;
        const pageSize = this.displayData.pageSize;

        if (totalItemCount > 1) {
            const startIndex = (this._pageNumber - 1) * pageSize + 1;

            const endIndex = Math.min(startIndex + pageSize - 1, totalItemCount);

            text = `${startIndex} - ${endIndex} ${this.labels.LB2BOf} ${totalItemCount} ${this.labels.LB2BItems}`;
        } else if (totalItemCount === 1) {
            text = this.labels.LB2BOneResult;
        }

        return text;
    }

    /**
     * Gets the normalized effective account of the user.
     *
     * @type {string}
     * @readonly
     * @private
     */
    get resolvedEffectiveAccountId() {
        const effectiveAcocuntId = this.effectiveAccountId || '';
        let resolved = null;

        if (effectiveAcocuntId.length > 0 && effectiveAcocuntId !== '000000000000000') {
            resolved = effectiveAcocuntId;
        }
        return resolved;
    }

    /**
     * Gets whether the cart is currently locked
     *
     * Returns true if the cart status is set to either processing or checkout (the two locked states)
     *
     * @readonly
     */
    get isCartLocked() {
        const cartStatus = (this._cartSummary || {}).status;
        return cartStatus === 'Processing' || cartStatus === 'Checkout';
    }

    /**
     * An object with the current PageReference.
     * This is needed for the pubsub library.
     *
     * @type {PageReference}
     */
    @wire(CurrentPageReference)
    pageRef;

    /**
     * The connectedCallback() lifecycle hook fires when a component is inserted into the DOM.
     */
    connectedCallback() {
        if (!!history.state) {
            this._pageNumber = history.state.pageNumber ? history.state.pageNumber : 1;
            this._refinements = history.state.refinements
                ? JSON.parse(history.state.refinements)
                : [];
           this.term = history.state.term ? history.state.term : undefined;
           this._isSortRuleId = history.state.sort ? history.state.sort : undefined;
        }
        this.updateCartInformation();
        this.triggerProductSearch();
    }

    /**
     * Handles a user request to clear all the filters.
     *
     * @private
     */
    handleClearAll(/*evt*/) {
        this._refinements = [];
        this._recordId = this._landingRecordId;
        this._pageNumber = 1;
        this.template.querySelector('c-lb2b-search-filter').clearAll();
        this.triggerProductSearch();
    }

    /**
     * Handles a user request to navigate to the product detail page.
     *
     * @private
     */
    handleShowDetail(evt) {
        evt.stopPropagation();

        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: evt.detail.productId,
                actionName: 'view'
            }
        });
    }

    /**
     * Handles a user request to navigate to previous page results page.
     *
     * @private
     */
    handlePreviousPage(evt) {
        evt.stopPropagation();
        this.indexVal = this.indexVal - 30;
        this._pageNumber = this._pageNumber - 1;
        this.triggerProductSearch();
    }

    /**
     * Handles a user request to navigate to next page results page.
     *
     * @private
     */
    handleNextPage(evt) {
        evt.stopPropagation();
        this.indexVal = this.indexVal + 30;
        this._pageNumber = this._pageNumber + 1;
        this.triggerProductSearch();
    }

    /**
     * Handles a user request to filter the results from facet section.
     *
     * @private
     */
    handleFacetValueUpdate(evt) {
        evt.stopPropagation();
        this._refinements = evt.detail.refinements;
        this._pageNumber = 1;
        this.triggerProductSearch();
    }

    /**
     * Handles a user request to show a selected category from facet section.
     *
     * @private
     */
    handleCategoryUpdate(evt) {
        evt.stopPropagation();
        this._recordId = evt.detail.categoryId;
        this._pageNumber = 1;
        this.triggerProductSearch();
    }

    /**
     * Handles the page navigation for the breadcrumbs
     *
     * @private
     */
    handleNavigateTo(event) {
        // prevent default navigation by href
        event.preventDefault();

        const urlBreadcrumb =
            communityBasePath + '/category/' + event.target.getAttribute('data-id');

        window.location.assign(urlBreadcrumb);
    }

    /**
     * Ensures cart information is up to date
     */
    updateCartInformation() {
        getCartSummary({
            communityId: communityId,
            effectiveAccountId: this.resolvedEffectiveAccountId,
            activeCartOrId: 'current'
        })
            .then((result) => {
                this._cartSummary = result;
            })
            .catch((e) => {
                // Handle cart summary error properly
                // For this sample, we can just log the error
                // console.log(e);
            });
    }

    _displayData;
    _isLoading = false;
    _pageNumber = 1;
    _refinements = [];
    _term;
    _recordId;
    _landingRecordId;
    @api
    cardContentMapping;
    _effectiveAccountId;
    refinementString;

    /**
     * The cart summary information
     * @type {ConnectApi.CartSummary}
     */
    _cartSummary;

    PushDatatoDataLayer(){
        SearchResultsEvent('search', this._term, this.displayData.total)
    }

    MoveToDataLayer() {
        NullSearchResultsEvent('null_search', this._term, this.displayData.total)
    }

    //added
    MoveDataToDataLayer(data){
        NavigationEvent('navigation_click','header nav', data);
    }

    handleSortRule(event){
        this._isSortRuleId = event.detail;
        this.triggerProductSearch();
    }

    @track mapData= [];
    mapDataFinal = [];
    MoveToDataLayerProducts() {
        for (var i = 0; i < this.displayData.layoutData.length; i++) {
            this.mapData.push(
                {
                   'item_name' : this.displayData.layoutData[i].name,
                    'item_brand' : this.displayData.layoutData[i].fields.Brand__c.value,
                    'item_id' : this.displayData.layoutData[i].fields.StockKeepingUnit.value,
                    'item_variant' : null,
                    'price' : this.displayData.layoutData[i].prices.negotiatedPrice,
                    'discount' : null,
                    'currency' : this.displayData.layoutData[i].prices.currencyIsoCode,
                    'index' : this.displayData.layoutData[i].index
                }); 
        }
        this.mapDataFinal = this.mapData;
        dispatchUpdateDataLayerEvent({
            'event': 'view_item_list',
            'ecommerce': {
                 'currency': this.displayData.layoutData[0].prices.currencyIsoCode,
                 'item_list_name': this.searchName,
                 'items': JSON.parse(JSON.stringify(this.mapDataFinal))
                }
       })
     }

}

export function dispatchUpdateDataLayerEvent(detail) {
    console.log('View item List ',detail);
     document.dispatchEvent(
     new CustomEvent('updatedatalayer', {
     detail
     })
     );
 }