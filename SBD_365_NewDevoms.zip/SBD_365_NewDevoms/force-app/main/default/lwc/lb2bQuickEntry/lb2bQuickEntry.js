import { LightningElement,track,api } from 'lwc';
import communityId from '@salesforce/community/Id';
import { toastUtil } from 'c/lb2bUtil';
import upload_result from '@salesforce/label/c.LB2BQuickEntryUploadResult';
import upload_sku from '@salesforce/label/c.LB2BUpload_Sku';
import upload_qty from '@salesforce/label/c.LB2BUpload_Qty';
import upload_notes from '@salesforce/label/c.LB2BUpload_Notes';
import upload_limits from '@salesforce/label/c.LB2BUpload_Limits';
import upload_qty_required from '@salesforce/label/c.LB2BUpload_Quantity_required';
import upload_sku_required from '@salesforce/label/c.LB2BUpload_Sku_required';
import upload_added_all from '@salesforce/label/c.LB2BUpload_Added_All';
import LB2BCopyPasteError from '@salesforce/label/c.LB2BCopyPasteError';
import LB2BAddToCart from '@salesforce/label/c.LB2BAddToCart';
import LB2BAddMore from '@salesforce/label/c.LB2BAddMore';
import LB2BQuickEntry from '@salesforce/label/c.LB2BQuickEntry';
import LB2BSkuNumber from '@salesforce/label/c.LB2BSkuNumber';
import LB2BItemSku from '@salesforce/label/c.LB2BItem';
import LB2BMinQtyErrorMsg from '@salesforce/label/c.LB2BMinQtyErrorMsg';
import LB2BMaxQtyErrorMsg from '@salesforce/label/c.LB2BMaxQtyErrorMsg';
import addToCart from '@salesforce/apex/LB2BCSVUploaderController.addToCart';
import {callDataLayerEvent} from 'c/lb2bDataLayer';
import {addtocartEvent} from 'c/lb2bDataLayer';

const columns = [
    { label: upload_sku, fieldName: 'sku' },
    { label: upload_qty, fieldName: 'qty' },
    {
        label: upload_notes,
        fieldName: 'notes',
        cellAttributes: { class: { fieldName: 'notesColor' }, wrapText: true }
    }
];
export default class Lb2bQuickEntry extends LightningElement {

    @api effectiveAccountId;
    @track productList = [];
    uploadInfo = [];
    inputData = [];
    @track isLoading = false;
    @track disabled = true;
    @track isCheckbox= false;
    @track showTable = false;
    showAllSuccessMessage = true;
    tableData = [];
    columns = columns;
    _sku;
    _qty;
    index = 0;

    label = {
        upload_sku,
        upload_qty,
        upload_notes,
        upload_result,
        upload_limits,
        upload_qty_required,
        upload_sku_required,
        upload_added_all,
        LB2BCopyPasteError,
        LB2BAddToCart,
        LB2BAddMore,
        LB2BQuickEntry,
        LB2BSkuNumber,
        LB2BItemSku,
        LB2BMinQtyErrorMsg,
        LB2BMaxQtyErrorMsg
    };
    
    

    connectedCallback(){
        this.skuTable();
    }

    skuTable(){
        if(this.productList.length<130){
            for(let i=0;i<5;i++){
                this.productList.push({
                    sku : '',
                    qty : ''
                });
            }
        }
    }

    addRow(){
        this.skuTable();
        console.log('Enter ',this.productList);
    }
    handleSkuChange(event) {
        let key = event.currentTarget.dataset.id;
        this.productList[key].sku = event.target.value.trim().replace(' ', '  ');
        this._sku = this.productList[key].sku;
    }
    
    handleQtyChange(event) {
        let key = event.currentTarget.dataset.id;
        this.productList[key].qty = event.target.value; 
        // to disbale the add to cart button if qty is greater than 1000000
        for (let i = 0; i < this.productList.length; i++) {
            var qty = this.productList[i].qty;
                if (qty != '' && qty != undefined  && qty !=0 && qty <= 1000000) {   
                    this.disabled = false;
                    
                } else if(qty != ''){
                    this.disabled = true;
                    break;
                }
        }

        this._qty = this.productList[key].qty;

        
    }

    uploadSku(){
        this.uploadInfo = [];
        this.inputData = [];

        let sku=JSON.parse(JSON.stringify(this.productList));
        console.log('plist',this.productList);

        let start = 0;
        for (let singleRow = start; singleRow < sku.length; singleRow++) {
            let rowCells = sku[singleRow];
            console.log('splitted rows rowCells[1]',Object.values(rowCells)[1]);
                let itemsku = Object.values(rowCells)[0];
                console.log('sku rowcell',itemsku);
                let qty = Object.values(rowCells)[1].trim();
                if ((itemsku!= '')&&(qty == '' || qty == undefined ||qty ==0)) {
                    let item = {};
                    item.sku = Object.values(rowCells)[0];
                    item.qty = Object.values(rowCells)[1];

                        if (qty == ''|| qty == undefined ||qty ==0) {
                            this.showAllSuccessMessage = false;
                            item.notesColor = 'slds-text-color_error';
                            item.notes = this.label.upload_qty_required;
                        }
                    this.inputData.push(item);
                    console.log('inputdata uploadsku',this.inputData);

                } else if (qty!= '' && (itemsku == '' || itemsku == undefined ||itemsku ==0)) {
                    let item = {};
                    item.sku = Object.values(rowCells)[0];
                    item.qty = Object.values(rowCells)[1];

                    if (itemsku == ''|| itemsku == undefined ||itemsku == 0) {
                        this.showAllSuccessMessage = false;
                        item.notesColor = 'slds-text-color_error';
                        item.notes = this.label.upload_sku_required;
                    }
                    this.inputData.push(item);

                } else if (itemsku !== null && qty !== null && qty > 0) {
                    this.uploadInfo.push({ sku: Object.values(rowCells)[0], quantity: Object.values(rowCells)[1]});
                    console.log('uploadinfo',this.uploadInfo);
                    }

        }
        if(this._qty || this._sku){
            this.onClickAddToCart();
        }
    }

    onClickAddToCart() {
        
        let dataSet = JSON.stringify(this.uploadInfo);
        console.log('add to cart(String):', dataSet);
        this.isLoading = true;
        addToCart({
            data: dataSet,
            communityId: communityId,
            effectiveAccountId: this.effectiveAccountId,
            isChecked: this.isCheckbox
        })
            .then((result) => {
                console.log('result:', result.data);
                this.isLoading = false;
               this.productList=[];
               this.skuTable();
                if (result.isSuccess) {
                    
                    if (this.showAllSuccessMessage) {
                        result.data.forEach((element) => {
                            if (!element.isSuccess) {
                                this.showAllSuccessMessage = false;
                                return;
                            }
                        });
                    }
                    result.data.forEach((element) => {
                        let item = {};
                        item.sku = element.sku;
                        item.qty = element.quantity;
                        item.notes = element.message;
                        item.notesColor = element.isSuccess ? 'slds-text-color_success' : 'slds-text-color_error';
                        this.inputData.push(item);

                         //code for google tags data layer starts  
                         if (!element.isSuccess) {
                            callDataLayerEvent('site_error', element.sku, element.quantity, element.message, 'Quick Entry');
                        }
                        if (element.isSuccess) {
                            this.index = this.index + 1;
                            console.log('index: ', this.index)
                            addtocartEvent('add_to_cart',null, null, element.sku,null, null, null, null, this.index, element.quantity);
                        }
                        //code for google tags data layer ends

                    });
                    this.index = 0;
                       

                    if (this.showAllSuccessMessage) {
                        toastUtil.toastSuccess(this, { message:this.label.upload_added_all });
                    }

                    this.tableData = this.inputData;
                   
                    console.log('tabel data',this.tableData);
                    if (this.tableData.length > 0) {
                        this.showTable = true;
                        this.disabled = true;
                    }

                    this.dispatchEvent(
                        new CustomEvent('cartchanged', {
                            bubbles: true,
                            composed: true
                        })
                    );
                } else {
                    toastUtil.toastError(this, { message: result.message });
                }
            })
            .catch((error) => {
                this.isLoading = false;
                let message = error && error.body && error.body.message;
                toastUtil.toastError(this, { message: message });
            });
    }



}