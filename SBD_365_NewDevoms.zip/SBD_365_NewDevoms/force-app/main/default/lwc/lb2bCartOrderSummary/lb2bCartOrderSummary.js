/**
 * This lb2bCartOrderSummary component is use in cart page with Checkout button.
 *
 * Data required the Order type, shiping condition, PO number and date fields to proceed to checkout.
 */

import { LightningElement, api, wire, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import PO_NUMBER from '@salesforce/schema/WebCart.UI_Po_Number__c';
import STORE_NUMBER from '@salesforce/schema/WebCart.SAP_Store_Number__c';
import ID_FIELD from '@salesforce/schema/WebCart.Id';
import REQUESTED_DELIVERY_DATE from '@salesforce/schema/WebCart.Requested_Delivery_Date__c';
import SHIPPING_CONDITION from '@salesforce/schema/WebCart.Shipping_Condition__c';
import LB2BCheckout from '@salesforce/label/c.LB2BCheckout';
import LB2BStoreNumber from '@salesforce/label/c.LB2BStoreNumber';
import LB2BRequestedDeliveryDate from '@salesforce/label/c.LB2BRequestedDeliveryDate';
import LB2BShippingCondition from '@salesforce/label/c.LB2BShippingCondition';
import LB2BSelectShipping from '@salesforce/label/c.LB2BSelectShipping';
import LB2BOrderSummary from '@salesforce/label/c.LB2BOrderSummary';
import LB2BPONumber from '@salesforce/label/c.LB2BPONumber';
import LB2BPoNumReq from '@salesforce/label/c.LB2BPoNumReq';
import LB2BAccountReq from '@salesforce/label/c.LB2BAccountReq';
import LB2BShipToReq from '@salesforce/label/c.LB2BShipToReq';
import LB2BNormalShipping from '@salesforce/label/c.LB2B_Normal_Shipping';
import LB2BSecondDay from '@salesforce/label/c.LB2B_Second_Day';
import LB2BNextDay from '@salesforce/label/c.LB2B_Next_Day';
import LB2BIndirectCustomer from '@salesforce/label/c.LB2B_Indirect_Customer';
import LB2BRegularCustomer from '@salesforce/label/c.LB2B_Regular_Customer';
import LB2BPremiumCutsomer from '@salesforce/label/c.LB2B_Premium_Cutsomer';
import LB2BWorkflowIdErrorMessage from '@salesforce/label/c.LB2BWorkflowIdErrorMessage';
import LB2BCostCenterErrorMessage from '@salesforce/label/c.LB2BCostCenterErrorMessage';
import LB2BGetPrice from '@salesforce/label/c.LB2BGetPrice';
import { updateRecord, getRecord } from 'lightning/uiRecordApi';
import getSapTotal from '@salesforce/apex/LB2BCartController.getSapTotal';
import getSapAccountFlags from '@salesforce/apex/LB2BCartController.getSapAccountFlags';
import { registerListener } from 'c/lb2bPubSub';
import { CurrentPageReference } from 'lightning/navigation';
import hasPermission from '@salesforce/customPermission/Internal_Sales_Rep';
import SalesRepCA from '@salesforce/customPermission/Sales_Rep_CA';
import ProfileName from '@salesforce/schema/User.Profile_Name__c';
import USER_ID from '@salesforce/user/Id';
import LB2BAboutToPlaceOrder from '@salesforce/label/c.LB2BAboutToPlaceOrder';
import LB2BAreYouSureWantToContinue from '@salesforce/label/c.LB2BAreYouSureWantToContinue';
import LB2BCancel from '@salesforce/label/c.LB2BCancel';
import LB2BConfirm from '@salesforce/label/c.LB2BConfirm';
import LB2BPcrCodeFormat from '@salesforce/label/c.LB2BPcrCodeFormat';
import { fireEvent } from 'c/lb2bPubSub';

export default class lb2bCartOrderSummary extends NavigationMixin(LightningElement) {
    @api isShippingCondition;
    @api isStoreNumReq;
    @api storeNumber;
    @api poNumber;
    @api requestedDeliveryDate;
    @api shippingConditionValue;
    @api getTodaysDate;
    @api getOrderSummary;
    @api isCartEmpty = false;
    @api cartIdFromLocalStorage;
    @api isErrorMsg;
    @api soldToAccSelector;
    @api shipToAccSelector;
    isLoading = false;
    @api checkSapFlags;
    @track error;
    @track isIndirectAccount;
    @track Internalsales;
    @track _isTargetedorPopFunds;
    @track _isWorkFlowId;
    @track costcenter;
    @track isModalOpen = false;
    @track numOfOrders;
    PName;
    isViewOnlyUser = true;
    validatedPCR = false;
    _isLineLevelWorkFlowId;
    navUrl;
    pcr_Notes;
    _reasonCode;

    label = {
        LB2BCheckout,
        LB2BRequestedDeliveryDate,
        LB2BShippingCondition,
        LB2BSelectShipping,
        LB2BOrderSummary,
        LB2BPONumber,
        LB2BStoreNumber,
        LB2BNormalShipping,
        LB2BSecondDay,
        LB2BNextDay,
        LB2BIndirectCustomer,
        LB2BRegularCustomer,
        LB2BPremiumCutsomer,
        LB2BWorkflowIdErrorMessage,
        LB2BCostCenterErrorMessage,
        LB2BGetPrice,
        LB2BAboutToPlaceOrder,
        LB2BAreYouSureWantToContinue,
        LB2BCancel,
        LB2BConfirm
    };

    @wire(getRecord, { recordId: USER_ID, fields: [ProfileName] })
    userDetails({ error, data }) {
        if (data) {
            this.PName = data.fields.Profile_Name__c.value;
            if (this.PName == 'LB2B Requestor View Only') {
                this.isViewOnlyUser = false;
            }
        } else if (error) {
            this.error = error;
        }
    }

    @wire(CurrentPageReference) pageRef;

    connectedCallback() {
        this.isLoading = true;
        registerListener('accountDependency', this.handleEvent, this);
        registerListener('multipleShipTo', this.handleMultipleShipTo, this);
        registerListener('invalidQuantity', this.handleQtyError, this);
        registerListener('CostcenterValue', this.costcentervalue, this);
        registerListener('InternalSalesCheck', this.isInternalSales, this);
        //register listener from cartcontent lwc to validate workflow Id is not undefined
        registerListener('isWorkFlowId', this.isWorkFlowId, this);
        registerListener('isLineLevelWorkFlowId', this.isLineLevelWorkFlowId, this);
        registerListener('isTargetedorPopFunds', this.isTargetedorPopFunds, this);
        registerListener('reasonCodeValue',this.isreasonCodeValue,this);
        registerListener('valdiatedPCR', this.isPcrValidated, this);
       // registerListener('valdiatedPCRCodes', this.isPcrCodesValidated, this);
        this.cartIdFromLocalStorage = localStorage.getItem('cartId');
        getSapTotal({
            webcartId: this.cartIdFromLocalStorage
        }).then((result) => {
            this.getOrderSummary = result[0];
            this.poNumber = this.getOrderSummary.UI_Po_Number__c;
            this.storeNumber = this.getOrderSummary.SAP_Store_Number__c;
            this.requestedDeliveryDate = this.getOrderSummary.Requested_Delivery_Date__c;
            this.shippingConditionValue = this.getOrderSummary.Shipping_Condition__c;
            console.log('order summary', this.getOrderSummary);
            this.getSapFlags(result[0].Sold_To_SAP_Account__c);
            if (this.getOrderSummary.UniqueProductCount != 0) {
                this.isCartEmpty = false;
            } else {
                this.isCartEmpty = true;
            }
            let array =
                this.getOrderSummary.LB2BMultiple_ShipTo_Ids__c != undefined
                    ? this.getOrderSummary.LB2BMultiple_ShipTo_Ids__c.split(',')
                    : [];
            this.numOfOrders = array.length;
            this.isLoading = false;
        });
    }

    /** isTargetedFunds & isWorkFlowId events to validate workflow id is not undefined */
    isTargetedorPopFunds(data) {
        this._isTargetedorPopFunds = data;
        console.log('_isTargetedorPopFunds >>> ',this._isTargetedorPopFunds);
    }

    isWorkFlowId(data) {
        this._isWorkFlowId = data;
    }

    isLineLevelWorkFlowId(data) {
        this._isLineLevelWorkFlowId = data;
    }

    costcentervalue(value) {
        return (this.costcenter = value);
    }
    isreasonCodeValue(value){
        return (this._reasonCode = value);
    }

    isInternalSales(value) {
        return (this.Internalsales = value);
    }

    handleQtyError(val) {
        if (val == true) {
            this.isCartEmpty = true;
        } else {
            this.isCartEmpty = false;
        }
    }

    handleEvent(inpVal) {
        if (inpVal.fromAccountType == 'SoldTo') {
            this.getSapFlags(inpVal.accountSelected);
            this.soldToAccSelector = inpVal.accountSelected;
        } else {
            this.shipToAccSelector = inpVal.accountSelected;
        }
    }

    handleMultipleShipTo(ids) {
        this.numOfOrders = ids.length;
    }

    getSapFlags(sapId) {
        getSapAccountFlags({
            sapAccountId: sapId
        }).then((result) => {
            this.checkSapFlags = result;
            this.isStoreNumReq =
                result[0] != undefined ? result[0].Store_Number_Required__c : false;
            this.isShippingCondition =
                result[0] != undefined ? result[0].Show_Shipping_Condition__c : false;
            this.isIndirectAccount = result[0] != undefined ? result[0].Indirect_Sold_To__c : false;
            this.storeNumberDigits = result[0].Store_Number_Digit_Count
                ? result[0].Store_Number_Digit_Count
                : 7;
            console.log('SapAccountData', result);
        });
    }

    handleStoreNumberChange(event) {
        this.storeNumber = event.target.value;
    }

    handlePoNumberChange(event) {
        this.poNumber = event.target.value;
    }

    handleDateChange(event) {
        this.requestedDeliveryDate = event.target.value;
    }

    handleShippingChange(event) {
        this.shippingConditionValue = event.target.value;
    }

    get shippingCondition() {
        return [
            { label: this.label.LB2BNormalShipping, value: 'A1' },
            { label: this.label.LB2BSecondDay, value: '2D' },
            { label: this.label.LB2BNextDay, value: 'ND' }
        ];
    }

    updateOrderSummaryToWebcart() {
        let url = (window.location.origin + window.location.pathname).split('/cart/');
        let fields = {};
        fields[ID_FIELD.fieldApiName] = url[1];
        fields[PO_NUMBER.fieldApiName] = this.poNumber;
        fields[STORE_NUMBER.fieldApiName] = this.storeNumber;
        fields[REQUESTED_DELIVERY_DATE.fieldApiName] =
            this.requestedDeliveryDate > this.getTodaysDate ? this.requestedDeliveryDate : '';
        fields[SHIPPING_CONDITION.fieldApiName] = this.shippingConditionValue;

        const recordInput = { fields: fields };
        updateRecord(recordInput)
            .then((result) => {
                console.log(result);
            })
            .catch((error) => {
                console.log('error', error);
            });

        console.log('Updated shipping condition to:', this.shippingConditionValue);
    }

    get options() {
        return [
            { label: this.label.LB2BIndirectCustomer, value: 'indirect customer' },
            { label: this.label.LB2BRegularCustomer, value: 'regular customer' },
            { label: this.label.LB2BPremiumCutsomer, value: 'permium customer' }
        ];
    }

    navigateToNext(event) {
        localStorage.setItem('SapAccount', this.isIndirectAccount);
        let url = window.location.origin + window.location.pathname;
        // let newUrl = url.replace(/cart/, 'checkout');
        let newUrl = url.replace(/cart/, 'order-review');
        if (
            this.requestedDeliveryDate > this.getTodaysDate ||
            this.requestedDeliveryDate == undefined
        ) {
            setTimeout(() => {
                this.navigateToWebPage(newUrl);
            }, 1500);
        }
        this.updateOrderSummaryToWebcart();
    }

    navigateToWebPage(url) {
        let _url = url;
        //fireEvent(this.pageRef, 'pcrvalidation');
        if (this.poNumber == undefined || this.poNumber == '') {
            let errMsg = LB2BPoNumReq;
            this.isErrorMsg = true;
            this.getToasterErrorMsg(errMsg);
        } else if(this.validatedPCR){ 
            let errMsg = LB2BPcrCodeFormat;
            this.isErrorMsg = true;
            this.getToasterErrorMsg(errMsg);             
         }
         else if (this.soldToAccSelector == undefined || this.soldToAccSelector == 'null') {
            let errMsg = LB2BAccountReq;
            this.getToasterErrorMsg(errMsg);
        } else if (
            (this.shipToAccSelector == undefined || this.shipToAccSelector == 'null') &&
            this.numOfOrders == 0
        ) {
            let errMsg = LB2BShipToReq;
            this.getToasterErrorMsg(errMsg);
        } else if (this._isTargetedorPopFunds) {
            if (this._isTargetedorPopFunds === 'LB2BTargetedFunds') {
                if (
                    !this._isWorkFlowId ||
                    this.costcenter === null ||
                    this.costcenter === undefined ||
                    this.costcenter === ''
                ) {
                    let errMsg;
                    if (!this.costcenter) {
                        errMsg = LB2BCostCenterErrorMessage;
                        this.getToasterErrorMsg(errMsg);
                    } else if(!SalesRepCA && !this._isWorkFlowId){
                        errMsg = LB2BWorkflowIdErrorMessage;
                        this.getToasterErrorMsg(errMsg);
                    } else if(SalesRepCA && !this._reasonCode){
                        errMsg = 'Reason code required';
                        this.getToasterErrorMsg(errMsg);
                    } else {
                        this.navigateUrl(_url);
                    }
                } else {
                    this.navigateUrl(_url);
                }
            } else if (this._isTargetedorPopFunds === 'LB2BFinishedGoods') {
                if (this._isLineLevelWorkFlowId) {
                    if (
                        this.costcenter === null ||
                        this.costcenter === undefined ||
                        this.costcenter === ''
                    ) {
                        let errMsg = LB2BCostCenterErrorMessage;
                        this.getToasterErrorMsg(errMsg);
                    } else {
                        this.navigateUrl(_url);
                    }
                } else {
                    this.navigateUrl(_url);
                }
            } else if (this._isTargetedorPopFunds === 'LB2BPointofPurchase') {
                if (
                    this.costcenter === null ||
                    this.costcenter === undefined ||
                    this.costcenter === ''
                ) {
                    let errMsg = LB2BCostCenterErrorMessage;
                    this.getToasterErrorMsg(errMsg);
                } else {
                    if (this.numOfOrders > 1) {
                        this.isModalOpen = true;
                        this.navUrl = _url;
                    } else {
                        this.navigateUrl(_url);
                    }
                }
            }
            else if (this._isTargetedorPopFunds === 'LB2BOnLoan') {
                if (
                    this.costcenter === null ||
                    this.costcenter === undefined ||
                    this.costcenter === ''
                ) {
                    let errMsg = LB2BCostCenterErrorMessage;
                    this.getToasterErrorMsg(errMsg);
                } else if (!this._reasonCode) {
                    let errMsg = 'Reason code required';
                    this.getToasterErrorMsg(errMsg);
                } else {
                    this.navigateUrl(_url);
                }
            }
        } else {
            this.navigateUrl(_url);
        }
    }

    getToasterErrorMsg(errMsg) {
        const event = new ShowToastEvent({
            title: errMsg,
            variant: 'error',
            mode: 'dismissable'
        });
        this.dispatchEvent(event);
    }

    get todaysDate() {
        var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
        var yyyy = today.getFullYear();
        today = yyyy + '-' + mm + '-' + dd;
        this.getTodaysDate = today;
        var tommorrow = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
        return tommorrow.toDateString('YYYY-MM-DD');
    }
    // Getter
    get hasInternalAccess() {
        return hasPermission;
    }

    navigateUrl(url) {
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: url
            }
        });
    }

    closeModal() {
        this.isModalOpen = false;
    }

    confirmAndNavigate() {
        this.navigateUrl(this.navUrl);
    }

    isPcrValidated(data){
        console.log('this.validatedCodesPCR', data);
        if(!data.isPcrcodeEmpty){
            if(data.pcrNotes.length >= 3 && data.pcrNotes.length <= 3000 ){
                this.validatedPCR = false;
            } else {
                this.validatedPCR = true;
            }

        } else {
            this.validatedPCR = false;
        }
    }
}