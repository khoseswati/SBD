/**
 * @description       : 
 * @author            : Stefanie Elling
 * @group             : 
 * @last modified on  : 08-01-2022
 * @last modified by  : Stefanie Elling
**/
import { LightningElement, api,wire, track } from 'lwc';
import { NavigationMixin, CurrentPageReference} from 'lightning/navigation';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';
import USER_ID from '@salesforce/user/Id';
import ProfileName from '@salesforce/schema/User.Profile_Name__c';
//import getHoldOrders from '@salesforce/apex/LB2BCartController.getHoldOrders';
import getSoldToNoData from '@salesforce/apex/LB2BCartController.getSoldToNoData';
import getOrdersOnHold from '@salesforce/apex/LB2BOrdersOnHoldHomepageController.getOrdersOnHold';
import LB2BHoldStatus from '@salesforce/label/c.LB2BHoldStatus';
import LB2BLineTotal from '@salesforce/label/c.LB2BLineTotal';
import LB2BOrders_On_Hold from '@salesforce/label/c.LB2BOrders_On_Hold';
import LB2BOrderNumber from '@salesforce/label/c.LB2BOrderNumber';
import LB2BPONumber from '@salesforce/label/c.LB2BPONumber';
import LB2BOrderDate from '@salesforce/label/c.LB2BOrderDate';
import LB2BSearch from '@salesforce/label/c.LB2BSearch';
import LB2BExportToExcel from '@salesforce/label/c.LB2BExportToExcel';
import LB2BShip_To from '@salesforce/label/c.LB2BShip_To';
import LB2BSold_To from '@salesforce/label/c.LB2BSold_To';
import GlobalCSS from "@salesforce/resourceUrl/lb2b_global";
import { loadStyle } from "lightning/platformResourceLoader";
import LB2BLoading from '@salesforce/label/c.LB2BLoading';
import hasPermission from '@salesforce/customPermission/Internal_Sales_Rep';

export default class Lb2bOrderOnHold extends NavigationMixin(LightningElement) {

    @api holdOrders;
    @api orders;
    @api orderNumber;
    PName;
    _IsView = true;
    isLoading = false;
    error;
    userId = USER_ID;
    pageLength = 15;
    page =1;
    visibleAccounts;
    currentPageReference = null;
    soldToNumber;
    @track hide;
    OrderNumberinLocalStorage = null;

    label={
        LB2BOrders_On_Hold,
        LB2BOrderNumber,
        LB2BHoldStatus,
        LB2BPONumber,
        LB2BOrderDate,
        LB2BLineTotal,
        LB2BSearch,
        LB2BExportToExcel,
        LB2BShip_To,
        LB2BSold_To,
        LB2BLoading
    }

    columnHeader=[
        this.label.LB2BOrderNumber, 
        this.label.LB2BPONumber,
        this.label.LB2BOrderDate,
        this.label.LB2BLineTotal,
        this.label.LB2BSold_To,
        this.label.LB2BShip_To
    ]

    @wire(getRecord, { recordId: USER_ID, fields: [ProfileName]}) 
    userDetails({error, data}) {
        if (data) {
            this.PName = data.fields.Profile_Name__c.value;
        } else if (error) {
            this.error = error ;
        }
    }

    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        if (currentPageReference) {
            this.soldToNumber = currentPageReference.state.soldtonumber;
        }
    }

    connectedCallback(){
       console.log('sold to number ', this.soldToNumber)
       this.isLoading = true;
        if(this.soldToNumber){
            
                getSoldToNoData({
                    soldToNumber : this.soldToNumber
                })
                .then(result=>{
                    this.isLoading = false;
                    this.holdOrders = result;
                })
                .catch(error=>{
                    console.log("error for sold to number : ", error)
                })

        }else{
            getOrdersOnHold({ userId: this.userId })
            .then(result => {
                console.log(' Hold Orders:', result);
                this.isLoading = false;
                this.holdOrders = result;
                this.orders = result;
            }).catch(error => {
                console.log('Error:', error);
            });
         
        }
    }

    renderedCallback() {
        loadStyle(this, GlobalCSS);
    }

    get IsView(){
        if(this.PName == 'LB2B Requestor View Only') {
            this._IsView = false;
            return false;
           }
           else{
            this._IsView = true;
            return true;
           }
    }

    updateSearch(event) {
        var regex = new RegExp(event.target.value, 'gi')
        console.log(event.target.value)
        this.holdOrders = this.orders.filter(
            row => regex.test(row.SAP_Order_Number__c) ||
                regex.test(row.PO_Number__c) ||
                regex.test(row.Order_Date__c) ||
                regex.test(row.Order_Net_Total__c) ||
                regex.test(row.Sold_To_Account__c) ||
                regex.test(row.Ship_To_Account__c) 
        );
    }

    handleNavigate(event){
        // getting order number from local storage
        this.OrderNumberinLocalStorage = JSON.parse(localStorage.getItem('Current Order Number'));
        this.orderNumber = event.currentTarget.dataset.value;
        if(this.orderNumber != this.OrderNumberinLocalStorage)
        {
            localStorage.clear();
        }
        // let url = (window.location.href).replace('/orders-on-hold', '/onhold-orderdetail');
        let url = (window.location.origin + window.location.pathname).replace('/orders-on-hold', '/onhold-orderdetail');
        this.navigateToWebPage(url);
    }

    navigateToWebPage(url) {
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: url + '?onholdorderNumber=' + this.orderNumber
            }
        });
    }

    updateAccountHandler(event){
        this.visibleAccounts=[...event.detail.records]
        console.log(event.detail.records)
    }

    exportToExcel(){
        // Prepare a html table
        let doc = '<table>';
        // Add styles for the table
        doc += '<style>';
        doc += 'table, th, td {';
        doc += '    border: 1px solid black;';
        doc += '    border-collapse: collapse;';
        doc += '}';          
        doc += '</style>';
        // Add all the Table Headers
        doc += '<tr>';
        this.columnHeader.forEach(element => {            
            doc += '<th>'+ element +'</th>'           
        });
        doc += '</tr>';
        // Add the data rows
        this.holdOrders.forEach(record => {
            if(record){
                doc += '<tr>';
                doc += '<th>'+record.SAP_Order_Number__c+'</th>'; 
                doc += '<th>'+record.PO_Number__c+'</th>'; 
                doc += '<th>'+record.Order_Date__c+'</th>'; 
                doc += '<th>'+record.Order_Net_Total__c +'</th>'; 
                doc += '<th>'+record.Sold_To_Account__c +'</th>'; 
                doc += '<th>'+record.Ship_To_Account__c +'</th>'; 
                doc += '</tr>';
            }
            else{
                doc += '<th>'+'</th>';

            }
        });
        doc += '</table>';
        var element = 'data:application/vnd.ms-excel,' + encodeURIComponent(doc);
        let downloadElement = document.createElement('a');
        downloadElement.href = element;
        downloadElement.target = '_self';
        // use .csv as extension on below line if you want to export data as csv
        downloadElement.download = 'Order on Hold List.xls';
        document.body.appendChild(downloadElement);
        downloadElement.click();
    }

    get ArrayLength(){
        if(this.holdOrders.length == 0){
            setTimeout(()=>{
                this.hide = true;
            },500);         
        }
        if(this.holdOrders.length != 0){
            this.hide = false;
        }
        return this.hide;
    }

}