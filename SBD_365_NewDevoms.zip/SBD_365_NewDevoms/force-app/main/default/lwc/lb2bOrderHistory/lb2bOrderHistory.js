import { LightningElement, api, track, wire } from 'lwc';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import ShortDate from '@salesforce/i18n/dateTime.shortDateFormat';
import LB2BOrder_History from '@salesforce/label/c.LB2BOrder_History';
import LB2BPONumber from '@salesforce/label/c.LB2BPONumber';
import LB2BSkuNumber from '@salesforce/label/c.LB2BSkuNumber';
import LB2BOrder_Dates from '@salesforce/label/c.LB2BOrder_Dates';
import LB2BSales_Order_Number from '@salesforce/label/c.LB2BSales_Order_Number';
import LB2BShip_To from '@salesforce/label/c.LB2BShip_To';
import LB2BSold_To from '@salesforce/label/c.LB2BSold_To';
import LB2BSales_Re_Filter from '@salesforce/label/c.LB2BSales_Re_Filter';
import LB2BList_Order from '@salesforce/label/c.LB2BList_Order';
import LB2BSearch from '@salesforce/label/c.LB2BSearch';
import LB2BHistorical from '@salesforce/label/c.LB2BHistorical';
import LB2BShipped from '@salesforce/label/c.LB2BShipped';
import LB2BOpenOrders from '@salesforce/label/c.LB2BOpenOrders';
import LB2BOrdersOnHold from '@salesforce/label/c.LB2BOrdersOnHold';
import LB2BBackOrders from '@salesforce/label/c.LB2BBackOrders';
import LB2BOrderNumber from '@salesforce/label/c.LB2BOrderNumber';
import LB2BStatus from '@salesforce/label/c.LB2BStatus';
import LB2BOrderType from '@salesforce/label/c.LB2BOrderType';
import LB2BDocumentDate from '@salesforce/label/c.LB2BDocumentDate';
import LB2BNetAmount from '@salesforce/label/c.LB2BNetAmount';
import LB2BShipToCustomer from '@salesforce/label/c.LB2BShipToCustomer';
import LB2BSoldToCustomer from '@salesforce/label/c.LB2BSoldToCustomer';
import LB2BShowing from '@salesforce/label/c.LB2BShowing';
import LB2BOf from '@salesforce/label/c.LB2BOf';
import LB2BTo from '@salesforce/label/c.LB2BTo';
import LB2BEntries from '@salesforce/label/c.LB2BEntries';
import LB2BInvoice from '@salesforce/label/c.LB2BInvoice';
import LB2BOrderDate from '@salesforce/label/c.LB2BOrderDate';
import LB2BOpen from '@salesforce/label/c.LB2BOpen';
import LB2BError from '@salesforce/label/c.LB2BError';
import LB2BErrorMessage from '@salesforce/label/c.LB2BErrorMessage';
import LB2BNoOrdersMsg from '@salesforce/label/c.LB2BNoOrdersMsg';
import LB2BMandatoryFieldsError from '@salesforce/label/c.LB2BMandatoryFieldsError';
import LB2BSelectShipTo from '@salesforce/label/c.LB2BSelectShipTo';
import LB2BAll from '@salesforce/label/c.LB2BAll';
import LB2BClosed from '@salesforce/label/c.LB2BClosed';
import LB2BOpenWBO from '@salesforce/label/c.LB2BOpenWBO';
import LB2BParShip from '@salesforce/label/c.LB2BPartiallyShipped';
import LB2BParInvoice from '@salesforce/label/c.LB2BPartiallyInvoiced';
import LB2BBlocked from '@salesforce/label/c.LB2BBlocked';
import LB2BPending from '@salesforce/label/c.LB2BPending';
import LB2BCancelled from '@salesforce/label/c.LB2BCancelled';
import LB2BBol from '@salesforce/label/c.LB2BBol';
import LB2BCreditBlock from '@salesforce/label/c.LB2BCreditBlock';
import LB2BExportToExcel from '@salesforce/label/c.LB2BExportToExcel';
import LB2BDropShipCity from '@salesforce/label/c.LB2BDropShipCity';
import LB2BDropShipState from '@salesforce/label/c.LB2BDropShipState';
import LB2BDropShipCountry from '@salesforce/label/c.LB2BDropShipCountry';
import LB2BShipToCustomerName from '@salesforce/label/c.LB2BShipToCustomerName';
import LB2BIsNotAvailable from '@salesforce/label/c.LB2BIsNotAvailable';
import LB2BNotAccess from '@salesforce/label/c.LB2BNotAccess';
import LB2BOk from '@salesforce/label/c.LB2BOk';
import LB2BOrderNumberError from '@salesforce/label/c.LB2BOrderNumberError';
import LB2BSearchCriteria from '@salesforce/label/c.LB2BSearchCriteria';
import LB2BFinishedGoods from '@salesforce/label/c.LB2BFinishedGoods';
import LB2BPage from '@salesforce/label/c.LB2BPage';
import LB2bPrevious from '@salesforce/label/c.LB2bPrevious';
import LB2BNext from '@salesforce/label/c.LB2BNext';
import LB2BListOrderNotes from '@salesforce/label/c.LB2BListOrderNotes';
import LB2BExportAffiliate from '@salesforce/label/c.LB2BExportAffiliate';
import LB2BDomesticAffiliate from '@salesforce/label/c.LB2BDomesticAffiliate';
import LB2BOrderHistoryPlaceHolder from '@salesforce/label/c.LB2BOrderHistoryPlaceHolder';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import GlobalCSS from '@salesforce/resourceUrl/lb2b_global';
import { loadStyle } from 'lightning/platformResourceLoader';
import USER_ID from '@salesforce/user/Id';
import LOCALE from '@salesforce/i18n/locale';
import getPdf from '@salesforce/apex/LB2BRestApiController.getPdf';
import getSearchResults from '@salesforce/apex/LB2BOrderHistoryController.getSearchResults';
import LB2BTargetedFunds from '@salesforce/label/c.LB2BTargetedFunds';
import LB2BFreeGoods from '@salesforce/label/c.LB2BFreeGoods';
import LB2BOnAccountOrder from '@salesforce/label/c.LB2BOnAccountOrder';
import LB2BReturnedOrder from '@salesforce/label/c.LB2BReturnedOrder';
import { TrackOrderHistory } from 'c/lb2bDataLayer';
import IS_EXPORT_AFFILIATE from '@salesforce/customPermission/Export_Affiliate_User';
import IS_DOMESTIC_AFFILIATE from '@salesforce/customPermission/Domestic_Affiliate_User';
import IS_INTERNAL_SALES from '@salesforce/customPermission/Internal_Sales_Rep';
import { TrackOrderHistoryNinetyDays } from 'c/lb2bDataLayer';
import { fireEvent } from 'c/lb2bPubSub';
import LB2BClearAllFilters from '@salesforce/label/c.LB2BClearAllFilters';
import LB2BCreditNotes from '@salesforce/label/c.LB2BCreditNotes';

export default class Lb2bOrderHistory extends NavigationMixin(LightningElement) {
    @api orderNumber;
    customFormModal = false;
    isLoader = false;
    customFormModal2 = false;
    searchByOrder = false;
    @track disableNext = true;
    @track disablePrevious = true;
    @track showResults = false;
    @track isMexican = false; 
    @track isOnAsc = false;
    @track isOnDesc = false;
    @track isPoAsc = false;
    @track isPoDesc = false;
    @track isOdAsc = false;
    @track isOdDesc = false;
    @track isNaAsc = false;
    @track isNaDesc = false;
    @track isSoldToAsc = false;
    @track isSoldToDesc = false;
    @track isShipToAsc = false;
    @track isShipToDesc = false;
    @track createDate;
    @track lastDate;

    soldToSelector;
    shipToSelector;
    firstLoadComplete = false;
    omniValue = false;
    urlQuery;

    /**
     * @typedef {Object} OrderHistoryItem
     *
     * @property {number} id
     * @property {string} orderNumber
     * @property {string} soldToNumber
     * @property {string} shipToNumber
     * @property {string} orderType
     * @property {string} orderStatus
     * @property {string} poNumber
     * @property {Date} documentDate
     * @property {number} netAmount
     * @property {string} status
     * @property {Array<string>} bolNumbers
     * @property {Array<string>} invoiceNumbers
     */

    /**
     * @typedef {Object} OrderHistoryResults
     *
     * @property {boolean} hasError
     * @property {string} errorMessage
     * @property {String} hasNextPage
     * @property {Array<OrderHistoryItem} orders
     * @property {string} query
     * @property {string} userMode
     */

    /**
     * @typedef {Object} OrderSearchInput
     *
     * @property {boolean} isAdvancedSearch
     * @property {string} soldToNumber
     * @property {string} shipToNumber
     * @property {string} reportFilter
     * @property {Date} startDate
     * @property {Date} endDate
     * @property {string} omniSearch
     * @property {number} pageNumber
     * @property {string} userId
     * @property {string} userLocale
     * @property {string} sortField
     * @property {string} sortDirection
     */

    /** @type {OrderSearchInput} */
    apexInputWrapper = {
        isAdvancedSearch: true,
        userId: USER_ID,
        userLocale: LOCALE,
        soldToNumber: null,
        shipToNumber: null,
        orderType: 'ALL',
        orderStatus: 'ALL',
        startDate: null,
        endDate: null,
        omniSearch: null,
        pageNumber: 1,
        // These teo are reserved for future use
        sortField: 'Order_Create_Date__c',
        sortDirection: 'DESC',
        doAllRecords: false
    };

    /** @type {OrderHistoryResults} */
    orderHistoryResults;

    label = {
        LB2BOrder_History,
        LB2BPONumber,
        LB2BSkuNumber,
        LB2BOrder_Dates,
        LB2BSales_Order_Number,
        LB2BShip_To,
        LB2BSold_To,
        LB2BSales_Re_Filter,
        LB2BList_Order,
        LB2BSearch,
        LB2BHistorical,
        LB2BShipped,
        LB2BOpenOrders,
        LB2BOrdersOnHold,
        LB2BBackOrders,
        LB2BOrderNumber,
        LB2BStatus,
        LB2BOrderType,
        LB2BDocumentDate,
        LB2BNetAmount,
        LB2BSoldToCustomer,
        LB2BShipToCustomer,
        LB2BShowing,
        LB2BOf,
        LB2BTo,
        LB2BEntries,
        LB2BInvoice,
        LB2BOrderDate,
        LB2BAll,
        LB2BClosed,
        LB2BOpen,
        LB2BOpenWBO,
        LB2BParShip,
        LB2BParInvoice,
        LB2BBlocked,
        LB2BPending,
        LB2BCancelled,
        LB2BCreditBlock,
        LB2BError,
        LB2BErrorMessage,
        LB2BNoOrdersMsg,
        LB2BMandatoryFieldsError,
        LB2BSelectShipTo,
        LB2BBol,
        LB2BExportToExcel,
        LB2BDropShipCity,
        LB2BDropShipState,
        LB2BDropShipCountry,
        LB2BShipToCustomerName,
        LB2BIsNotAvailable,
        LB2BNotAccess,
        LB2BOk,
        LB2BOrderNumberError,
        LB2BSearchCriteria,
        LB2BPage,
        LB2bPrevious,
        LB2BNext,
        LB2BListOrderNotes,
        LB2BExportAffiliate,
        LB2BDomesticAffiliate,
        LB2BOrderHistoryPlaceHolder,
        LB2BClearAllFilters,
        LB2BCreditNotes
    };

    columnHeader = [
        this.label.LB2BOrderNumber,
        this.label.LB2BStatus,
        this.label.LB2BOrderType,
        this.label.LB2BPONumber,
        this.label.LB2BDocumentDate,
        this.label.LB2BNetAmount,
        this.label.LB2BSoldToCustomer,
        this.label.LB2BShipToCustomer
    ];

    get orderTypeOptions() {
        let options = [];

        if (!!IS_EXPORT_AFFILIATE) {
            options.push({ label: LB2BExportAffiliate, value: 'ZX1' });
            return options;
        }

        if (!!IS_DOMESTIC_AFFILIATE) {
            options.push({ label: LB2BDomesticAffiliate, value: 'ZS2' });
            return options;
        }

        options.push({ label: LB2BAll, value: 'ALL' });

        if (LOCALE == 'en-US') {
            options.push({ label: LB2BFinishedGoods, value: 'OR TA' });
            options.push({ label: LB2BReturnedOrder, value: 'RE' });
        } else if (LOCALE == 'fr-CA') {
            options.push({ label: LB2BFinishedGoods, value: 'OR TA' });
        } else if (LOCALE == 'es-MX') {
            options.push({ label: LB2BFinishedGoods, value: 'ZMXA' });
            options.push({ label: LB2BReturnedOrder, value: 'ZMXC' });
            options.push({ label: LB2BCreditNotes, value: 'ZMXE' });
        }

        if (!!IS_INTERNAL_SALES) {
            options.push({ label: LB2BTargetedFunds, value: 'ZGA ZRP' });
            options.push({ label: LB2BFreeGoods, value: 'ZSLS' });
        }

        options.push({ label: LB2BOnAccountOrder, value: 'ZSA0' });

        return options;
    }

    get orderStatusOptions() {
        return [
            { label: LB2BAll, value: 'ALL' },
            { label: LB2BOpen, value: 'A B' },
            { label: LB2BParShip, value: 'C' },
            { label: LB2BParInvoice, value: 'E' },
            { label: LB2BShipped, value: 'D F' },
            { label: LB2BCancelled, value: 'X' },
            { label: LB2BBlocked, value: 'BLOCKED CreditBlock' },
            { label: LB2BPending, value: 'Pending' }
        ];
    }

    get omniSearch() {
        if (window.location.href.includes('tabset')) {
            if (localStorage.getItem('orderHistoryRecords')) {
                let localData = JSON.parse(localStorage.getItem('orderHistoryRecords'));
                return localData.omniSearch;
            } else {
                return '';
            }
        } else {
            let retainStatus = JSON.parse(JSON.stringify(history.state));
            if (retainStatus.apexInputWrapper) {
                return retainStatus.apexInputWrapper.omniSearch;
            } else if (this.omniValue){
                return this.apexInputWrapper.omniSearch;
            } else {
                return '';
            }
        }
    }

    get orderTypePlaceholder() {
        // return this.orderTypeOptions[0].label;
        if (window.location.href.includes('tabset')) {
        } else {
            let retainStatus = JSON.parse(JSON.stringify(history.state));
            if (retainStatus.apexInputWrapper) {
                if (!!IS_EXPORT_AFFILIATE) {
                    if (retainStatus.apexInputWrapper.orderType === 'ZX1') {
                        return LB2BExportAffiliate;
                    }
                }

                if (!!IS_DOMESTIC_AFFILIATE) {
                    if (retainStatus.apexInputWrapper.orderType === 'ZS2') {
                        return LB2BDomesticAffiliate;
                    }
                }

                if (LOCALE == 'en-US') {
                    if (retainStatus.apexInputWrapper.orderType === 'OR TA') {
                        return LB2BFinishedGoods;
                    } else if (retainStatus.apexInputWrapper.orderType === 'RE') {
                        return LB2BReturnedOrder;
                    } else if (retainStatus.apexInputWrapper.orderType === 'ZSLS') {
                        return LB2BFreeGoods;
                    } else {
                        return LB2BAll;
                    }
                } else if (LOCALE == 'fr-CA') {
                    // None specified
                    if (retainStatus.apexInputWrapper.orderType === 'OR TA') {
                        return LB2BFinishedGoods;
                    } else {
                        return LB2BAll;
                    }
                } else if (LOCALE == 'es-MX') {
                    if (retainStatus.apexInputWrapper.orderType === 'ZMXA') {
                        return LB2BFinishedGoods;
                    } else if (retainStatus.apexInputWrapper.orderType === 'ZMXC') {
                        return LB2BReturnedOrder;
                    } else if (retainStatus.apexInputWrapper.orderType === 'ZMXE') {
                        return LB2BCreditNotes;
                    } else {
                        return LB2BAll;
                    }
                }

                if (!!IS_INTERNAL_SALES) {
                    if (retainStatus.apexInputWrapper.orderType === 'ZGA ZRP') {
                        return LB2BTargetedFunds;
                    } else if (retainStatus.apexInputWrapper.orderType === 'ZSLS') {
                        return LB2BFreeGoods;
                    } else {
                        return LB2BAll;
                    }
                }
            } else {
                return this.orderTypeOptions[0].label;
            }
        }
    }

    get orderStatusPlaceholder() {
        if (window.location.href.includes('tabset')) {
        } else {
            let retainStatus = JSON.parse(JSON.stringify(history.state));
            if (retainStatus.apexInputWrapper) {
                if (retainStatus.apexInputWrapper.orderStatus === 'A B') {
                    return LB2BOpen;
                } else if (retainStatus.apexInputWrapper.orderStatus === 'C') {
                    return LB2BParShip;
                } else if (retainStatus.apexInputWrapper.orderStatus === 'E') {
                    return LB2BParInvoice;
                } else if (retainStatus.apexInputWrapper.orderStatus === 'D F') {
                    return LB2BShipped;
                } else if (retainStatus.apexInputWrapper.orderStatus === 'X') {
                    return LB2BCancelled;
                } else if (retainStatus.apexInputWrapper.orderStatus === 'BLOCKED CreditBlock') {
                    return LB2BBlocked;
                } else if (retainStatus.apexInputWrapper.orderStatus === 'Pending') {
                    return LB2BPending;
                } else {
                    return LB2BAll;
                }
            } else {
                return this.orderStatusOptions[0].label;
            }
        }
        // return this.orderStatusOptions[0].label;
    }

    get dateRange() {
        return [
            { label: 'This Week', value: 'THIS_WEEK' },
            { label: 'This Month', value: 'THIS_MONTH' },
            { label: 'This Quarter', value: 'THIS_QUARTER' },
            { label: 'Last 6 Months', value: 'LAST_N_DAYS:180' },
            { label: 'This Year', value: 'THIS_YEAR' }
        ];
    }

    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        console.log('ourl', window.location.href);
        if (window.location.href.includes('tabset')) {
            this.apexInputWrapper.isAdvancedSearch = false;
            this.searchByOrder = true;
        } else {
            this.apexInputWrapper.isAdvancedSearch = true;
            this.searchByOrder = false;
            this.showResults = false;
        }
    }

    @wire(CurrentPageReference) pageRef;

    connectedCallback() {}

    handleCreateChange(event) {
        this.createDate = event.target.value;
        this.apexInputWrapper.startDate = event.target.value;
        this.apexInputWrapper.pageNumber = 1;
        this.omniValue = true;
    }
    handleLastChange(event) {
        this.lastDate = event.target.value;
        this.apexInputWrapper.endDate = event.target.value;
        this.apexInputWrapper.pageNumber = 1;
        this.omniValue = true;
    }

    handleOmniSearchChanged(event) {
        this.apexInputWrapper.omniSearch = event.target.value;
        this.apexInputWrapper.pageNumber = 1;
    }

    handleSoldToAccountSelected(evt) {
        const acctNumber = evt.detail;
        if (!acctNumber) {
            this.apexInputWrapper.shipToNumber = null;
        }

        this.apexInputWrapper.soldToNumber = acctNumber;
        this.apexInputWrapper.pageNumber = 1;
    }

    handleShipToAccountSelected(evt) {
        const acctNumber = evt.detail;
        if (!acctNumber) {
            this.apexInputWrapper.soldToNumber = null;
        }

        this.apexInputWrapper.shipToNumber = acctNumber;
        this.apexInputWrapper.pageNumber = 1;
    }

    handleOrderTypeChanged(evt) {
        console.log(evt.detail.value);
        this.apexInputWrapper.orderType = evt.detail.value;
        this.apexInputWrapper.pageNumber = 1;
    }

    handleOrderStatusChanged(evt) {
        console.log(evt.detail.value);
        this.apexInputWrapper.orderStatus = evt.detail.value;
        this.apexInputWrapper.pageNumber = 1;
    }

    handleNavigate(event) {
        this.orderNumber = event.currentTarget.dataset.value;
        let url = window.location.origin + window.location.pathname;
        let newUrl = url.replace('/OrderSummary/OrderSummary/Default', '/sap-order-detail');
        console.log('url123', newUrl);
        this.navigateToWebPage(newUrl);
    }

    navigateToWebPage(url) {
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: url + '?orderNumber=' + this.orderNumber
            }
        });
    }

    handleAccrdionTable(event) {
        console.log('Click Icon', event);
        let accordionBtns = this.template.querySelectorAll('.accordion');

        console.log('accordionBtns', accordionBtns);

        this.template.querySelectorAll('.is-open').length
            ? this.template.querySelectorAll('.is-open').forEach((item) => {
                  item.classList.remove('is-open');
              })
            : null;

        accordionBtns.forEach((item) => {
            item.addEventListener('click', () => {
                item.parentElement.parentElement.classList.contains('is-open')
                    ? item.parentElement.parentElement.classList.remove('is-open')
                    : item.parentElement.parentElement.classList.add('is-open');
            });
        });
    }

    customDelete(event) {
        this.customFormModal2 = false;
    }

    renderedCallback() {
        if (!this.firstLoadComplete) {
            this.firstLoadComplete = true;

            this.soldToSelector = this.template.querySelectorAll('c-lb2b-account-selector-v2')[0];
            this.shipToSelector = this.template.querySelectorAll('c-lb2b-account-selector-v2')[1];

            if (window.location.href.includes('tabset')) {
                /** To retain record for search by order  */
                if (localStorage.getItem('orderHistoryRecords')) {
                    console.log(
                        'local storage: ',
                        JSON.parse(localStorage.getItem('orderHistoryRecords'))
                    );
                    // this.orderHistoryResults = JSON.parse(localStorage.getItem('orderHistoryRecords'));
                    let localData = JSON.parse(localStorage.getItem('orderHistoryRecords'));
                    this.orderHistoryResults = localData.historyRecords;
                    this.showResults = this.orderHistoryResults.orders.length > 0 ? true : false;
                    this.disableNext = this.orderHistoryResults.hasNextPage == true ? false : true;
                    this.disablePrevious = this.apexInputWrapper.pageNumber == 1 ? true : false;

                    setTimeout(() => {
                        localStorage.clear('orderHistoryRecords');
                    }, 5000);
                }
            } else {
                const params = Object.fromEntries(new URLSearchParams(window.location.search));
                console.log(params.q);
                if (params.q) {
                    const encodedData = params.q;
                    const decodedData = atob(encodedData);
                    console.log(encodedData);
                    console.log(decodedData);
                    this.apexInputWrapper = JSON.parse(decodedData);
                    this.handleSearch();
                    return;
                }

                /** To retain records for Advance search  */
                let retainData = JSON.parse(JSON.stringify(history.state));
                console.log('retain :', retainData);
                if (retainData.apexInputWrapper) {
                    this.apexInputWrapper = retainData.apexInputWrapper;
                    this.createDate = this.apexInputWrapper.startDate;
                    this.lastDate = this.apexInputWrapper.endDate;
                    this.handleSearch();

                    setTimeout(() => {
                        const soldToNumber = retainData.apexInputWrapper.soldToNumber;
                        const shipToNumber = retainData.apexInputWrapper.shipToNumber;

                        /**To retain value of sold to and ship to account  */
                        if (soldToNumber) {
                            console.log('Setting sold to selector to:', soldToNumber);
                            this.soldToSelector.setSelectedAccount(soldToNumber);
                        } else {
                            console.log('No sold to number found to set');
                        }
                        if (shipToNumber) {
                            console.log('Setting sold to selector to:', shipToNumber);
                            this.shipToSelector.setSelectedAccount(shipToNumber);
                        } else {
                            console.log('No ship to number found to set');
                        }
                    }, 3000);
                }
            }
        }

        this.handleAccrdionTable();
        loadStyle(this, GlobalCSS);
    }

    handleSearch() {
        this.isLoader = true;
        let searchCriteriaString = JSON.stringify(this.apexInputWrapper);
        console.log('Search criteria:', searchCriteriaString);
        console.log('local : ', LOCALE);

        getSearchResults({ inputString: searchCriteriaString })
            .then((result) => {
                this.isLoader = false;
                console.log('result for get search orders : ', result);
                if (result.hasError) {
                    console.log('Error:', result.errorMessage);
                    console.log(result.query);
                    this.showResults = false;
                    
                    let historyObj = {};
                    historyObj.apexInputWrapper = this.apexInputWrapper;
                    history.replaceState(historyObj, '');

                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Error',
                            message: result.errorMessage,
                            variant: 'error',
                            mode: 'dismissable'
                        })
                    );
                } else {
                    console.log('Results:', result);
                    this.showResults = result.orders.length > 0 ? true : false;
                    this.orderHistoryResults = result;

                    //hide + - button if bol & invoice is not available
                    for (let i = 0; i < this.orderHistoryResults.orders.length; i++) {
                        let bol = this.orderHistoryResults.orders[i].bolNumbers;
                        let invoice = this.orderHistoryResults.orders[i].invoiceNumbers;

                        if (bol.length == 0 && invoice.length == 0) {
                            this.orderHistoryResults.orders[i].hideAccordion = true;
                        } else {
                            this.orderHistoryResults.orders[i].hideAccordion = false;
                        }
                    }

                    /** To store data in localstorage if search by order */
                    if (this.searchByOrder) {
                        let localData = {};
                        localData.omniSearch = this.apexInputWrapper.omniSearch;
                        localData.historyRecords = this.orderHistoryResults;
                        console.log('localData: ', localData);
                        localStorage.setItem('orderHistoryRecords', JSON.stringify(localData));
                    } else {
                        let historyObj = {};
                        historyObj.pageNo = this.apexInputWrapper.pageNumber;
                        historyObj.orderRecords = this.orderHistoryResults;
                        historyObj.apexInputWrapper = this.apexInputWrapper;
                        console.log('historyObj: ', historyObj);
                        history.replaceState(historyObj, '');
                    }
                    //** end of code  */

                    this.disableNext = this.orderHistoryResults.hasNextPage == true ? false : true;
                    this.disablePrevious = this.apexInputWrapper.pageNumber == 1 ? true : false;
                }
            })
            .catch((error) => {
                this.isLoader = false;
                this.showResults = false;
                console.error(error);
            });
    }

    nextHandleSearch() {
        this.apexInputWrapper.pageNumber++;
        this.handleSearch();
    }

    previousHandleSearch() {
        this.apexInputWrapper.pageNumber--;
        this.handleSearch();
    }

    callRestApi(evt) {
        this.isLoader = true;
        let _name = evt.currentTarget.name;
        let _invoice = '';
        let _bol = '';
        let fileName = '';

        if (_name == 'Invoice') {
            _invoice = evt.currentTarget.dataset.value;
            fileName = _invoice;
        } else {
            _bol = evt.currentTarget.dataset.value;
            fileName = _bol;
        }

        let _orderNumber = evt.currentTarget.dataset.id;
        if (LOCALE == 'en-MX') {
            this.isMexican = true;
        }

        getPdf({
            invoice: _invoice,
            orderNumber: _orderNumber,
            bol: _bol,
            isMexican: this.isMexican
        })
            .then((result) => {
                this.isLoader = false;
                console.log('result of restAPI: ', result);
                if (result) {
                    let downloadLink = document.createElement('a');
                    downloadLink.href = 'data:application/pdf;base64,' + result;
                    downloadLink.download = fileName;
                    downloadLink.click();
                } else {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Error',
                            message: _name + ' ' + this.label.LB2BIsNotAvailable,
                            variant: 'error',
                            mode: 'dismissable'
                        })
                    );
                }
            })
            .catch((error) => {
                this.isLoader = false;
                console.log('error for invoice : ', error);
            });
    }

    sort(event) {
        this.isOnAsc = false;
        this.isOnDesc = false;
        this.isPoAsc = false;
        this.isPoDesc = false;
        this.isOdAsc = false;
        this.isOdDesc = false;
        this.isNaAsc = false;
        this.isNaDesc = false;
		this.isSoldToAsc = false;
        this.isSoldToDesc = false;
        this.isShipToAsc = false;
        this.isShipToDesc = false;
   
        this.apexInputWrapper.sortField = event.currentTarget.dataset.id;   
        this.apexInputWrapper.sortDirection =
            this.apexInputWrapper.sortDirection === 'DESC' ? 'ASC' : 'DESC';

        switch (this.apexInputWrapper.sortField) {

            case 'Order_Number__c':
                if (this.apexInputWrapper.sortDirection === 'ASC') {
                    this.isOnAsc = true;
                } else {
                    this.isOnDesc = true;
                }
                break;
        
        
            case 'PO_Number__c':
                if (this.apexInputWrapper.sortDirection === 'ASC') {
                    this.isPoAsc = true;
                } else {
                    this.isPoDesc = true;
                }
                break;
        
            case 'Order_Create_Date__c':
                if (this.apexInputWrapper.sortDirection === 'ASC') {
                    this.isOdAsc = true;
                } else {
                    this.isOdDesc = true;
                }
                break;
        
            case 'Net_Amount__c':
                if (this.apexInputWrapper.sortDirection === 'ASC') {
                    this.isNaAsc = true;
                } else {
                    this.isNaDesc = true;
                }
                break;
        
            case 'Sold_To_Account_Number__c':
                if (this.apexInputWrapper.sortDirection === 'ASC') {
                    this.isSoldToAsc = true;
                } else {
                    this.isSoldToDesc = true;
                }
                break;
        
            case 'Ship_To_Account_Number__c':
                if (this.apexInputWrapper.sortDirection === 'ASC') {
                    this.isShipToAsc = true;
                } else {
                    this.isShipToDesc = true;
                }
                break;
        }
        this.handleSearch();
    }

    exportToExcel() {

        //2921 chnages starts here
        
        let fullOrderInputWrapper = {
            ...this.apexInputWrapper
            };
            fullOrderInputWrapper.doAllRecords = true;
            const searchCriteriaString = JSON.stringify(fullOrderInputWrapper);
            getSearchResults({ inputString: searchCriteriaString })
            .then((Results) => {
                if (Results.hasError) {
                    console.error('Error:', Results.errorMessage);
                }else{
                //console.log('result excel >>> ',Results)
                let doc = '<table>';
                doc += '<style>';
                doc += 'table, th, td {';
                doc += '    border: 1px solid black;';
                doc += '    border-collapse: collapse;';
                doc += '}';
                doc += '</style>';
                // Adding all the Table Headers
                doc += '<tr>';
                this.columnHeader.forEach((element) => {
                    doc += '<th>' + element + '</th>';
                });
                doc += '</tr>';
                // Adding the data rows
                Results.orders.forEach((record) => {
                    if (record) {
                        doc += '<tr>';
                        doc += '<th>' + record.orderNumber + '</th>';
                        doc += '<th>' + record.status + '</th>';
                        doc += '<th>' + record.orderType + '</th>';
                        doc += '<th>' + record.poNumber + '</th>';
                        doc += '<th>' + record.documentDate + '</th>';
                        doc += '<th>' + record.netAmount + '</th>';
                        doc += '<th>' + record.soldToNumber + '</th>';
                        doc += '<th>' + record.shipToNumber + '</th>';
                        doc += '</tr>';
                        console.log('doc', doc);
                    } else {
                        doc += '<th>' + '</th>';
                    }
                });
                doc += '</table>';
                var element = 'data:application/vnd.ms-excel,' + encodeURIComponent(doc);
                let downloadElement = document.createElement('a');
                downloadElement.href = element;
                downloadElement.target = '_self';
                downloadElement.download = 'Order History List.xls';
                document.body.appendChild(downloadElement);
                downloadElement.click();
            

            }
        });

        //2921 code ends

        }

    MoveToDataLayer() {
        TrackOrderHistory(
            'order_history_search',
            this.soldTo,
            this.shipTo,
            this.createDate,
            this.lastDate,
            this.PONumber,
            this.SalesOrderNo
        );
    }

    //clear all filter method 
    clearAllFilters(){
        console.log('handle clear')
        this.handleAccrdionTable();

        if (
            this.apexInputWrapper.omniSearch !== null ||
            this.apexInputWrapper.endDate !== null ||
            this.apexInputWrapper.startDate !== null ||
            this.apexInputWrapper.shipToNumber !== null ||
            this.apexInputWrapper.soldToNumber !== null ||
            this.apexInputWrapper.orderType !== 'ALL' ||
            this.apexInputWrapper.orderStatus !== 'ALL'
        ) {
            this.isLoader = true;
            this.createDate = null;
            this.lastDate = null;

            this.apexInputWrapper.omniSearch = null;
            this.apexInputWrapper.endDate = null;
            this.apexInputWrapper.isAdvancedSearch = true;
            this.apexInputWrapper.userId = USER_ID;
            this.apexInputWrapper.userLocale = LOCALE;
            this.apexInputWrapper.soldToNumber = null;
            this.apexInputWrapper.shipToNumber = null;
            this.apexInputWrapper.orderType = 'ALL';
            this.apexInputWrapper.orderStatus = 'ALL';
            this.apexInputWrapper.startDate = null;
            this.apexInputWrapper.pageNumber = 1;
            this.apexInputWrapper.sortField = 'Order_Create_Date__c';
            this.apexInputWrapper.sortDirection = 'DESC';

            this.template.querySelectorAll('c-lb2b-account-selector-v2')[0].clearFilter();
            this.template.querySelectorAll('c-lb2b-account-selector-v2')[1].clearFilter();

            this.template.querySelectorAll('lightning-combobox').forEach((element) => {
                element.value = null;
            });

            let historyObj = {};
            console.log('historyObj: ', historyObj);
            history.replaceState(historyObj, '');
            this.isLoader = false;
        }

        
    }

}