import { LightningElement, api } from 'lwc';
import LB2BUpcCode from '@salesforce/label/c.LB2BUpcCode';
import { NavigationMixin } from 'lightning/navigation';
import { HtmlHelper } from 'c/lb2bUtil';
import { productView } from 'c/lb2bDataLayer';

export default class Lb2bProductDetailsDisplay extends NavigationMixin(LightningElement) {

    label = {
        LB2BUpcCode
    };
    /**
   * A product field.
   * @typedef {object} CustomField
   *
   * @property {string} name
   *  The name of the custom field.
   *
   * @property {string} value
   *  The value of the custom field.
   */

    /**
     * An iterable Field for display.
     * @typedef {CustomField} IterableField
     *
     * @property {number} id
     *  A unique identifier for the field.
     */
    @api brand;
    @api description;
    @api upc;
    @api stock;
    @api stockcolor;
    @api features;
    @api currencycode;
    @api productname;
    @api productsku;

    /**
     * Gets or sets which custom fields should be displayed (if supplied).
     *
     * @type {CustomField[]}
     */
    @api
    customFields;

    /**
     * Gets the iterable fields.
     *
     * @returns {IterableField[]}
     *  The ordered sequence of fields for display.
     *
     * @private
     */
    get _displayableFields() {
        // Enhance the fields with a synthetic ID for iteration.
        return (this.customFields || []).map((field, index) => ({
            ...field,
            id: index
        }));
    }

    get _features(){
        const val=  this.features;
        // this.features=val;
        return val.split("||").slice(0, 10);
     }

    connectedCallback() {
        this.description = HtmlHelper.parseHtml(this.description);
        productView('view_item',this.currencycode,this.productname,this.brand,this.productsku,null,this.upc,null);
    }
}