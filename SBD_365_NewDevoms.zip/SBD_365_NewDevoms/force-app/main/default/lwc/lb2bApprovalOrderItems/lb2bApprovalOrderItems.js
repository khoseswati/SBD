import { LightningElement, api } from 'lwc';
import getOrderItems from '@salesforce/apex/LB2BApprovalOrderItemsController.getOrderItems';

export default class Lb2bApprovalOrderItems extends LightningElement {
    @api
    recordId;

    orderLineItems = [
        {
            Id: '1',
            Product2: {
                Name: 'test 1',
                StockKeepingUnit: 'aaa'
            },
            Quantity: 10,
            UnitPrice: 14.5,
            TotalPrice: 145.0,
            Order: {
                CurrencyIsoCode: 'USD'
            }
        },
        {
            Id: '2',
            Product2: {
                Name: 'test long product name this is a long name',
                StockKeepingUnit: 'avsidfhnofgd'
            },
            Quantity: 2,
            UnitPrice: 189.0,
            TotalPrice: 189.0,
            Order: {
                CurrencyIsoCode: 'MXN'
            }
        }
    ];

    connectedCallback() {
        getOrderItems({ recordId: this.recordId })
            .then((result) => {
                console.log(result);
                this.orderLineItems = result;
            })
            .catch((error) => {
                console.error(error);
            });
    }

    get hasItems() {
        return this.orderLineItems.length > 0;
    }
}