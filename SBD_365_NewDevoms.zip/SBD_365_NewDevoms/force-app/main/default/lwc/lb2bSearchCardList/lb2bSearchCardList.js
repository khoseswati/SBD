import { LightningElement, api, track, wire } from 'lwc';
import LOCALE from '@salesforce/i18n/locale';
import LB2BPriceInCart from '@salesforce/label/c.LB2BPriceInCart';
import LB2BSku from '@salesforce/label/c.LB2BSku';
import {productClick} from 'c/lb2bDataLayer'; 

/**
 * An organized display of a single product card.
 *
 * @fires SearchCard#calltoaction
 * @fires SearchCard#showdetail
 */
export default class lb2bSearchCardList extends LightningElement {
    label = {
        LB2BPriceInCart,
        LB2BSku
    };

    checkItemQuantity = true;
    isInStock = true;
    isMexico = false;
    isCanada = false;
    isUsa = false;
    //variables for the incrementor
    minus = this.template.querySelector('minus');
    num = this.template.querySelector('num');

    @api displayMode;
        ;
    @api effectiveAccountId;

    /**
     * An event fired when the user clicked on the action button. Here in this
     *  this is an add to cart button.
     *
     * Properties:
     *   - Bubbles: true
     *   - Composed: true
     *   - Cancelable: false
     *
     * @event SearchLayout#calltoaction
     * @type {CustomEvent}
     *
     * @property {String} detail.productId
     *   The unique identifier of the product.
     *
     * @export
     */

    /**
     * An event fired when the user indicates a desire to view the details of a product.
     *
     * Properties:
     *   - Bubbles: true
     *   - Composed: true
     *   - Cancelable: false
     *
     * @event SearchLayout#showdetail
     * @type {CustomEvent}
     *
     * @property {String} detail.productId
     *   The unique identifier of the product.
     *
     * @export
     */

    /**
     * A result set to be displayed in a layout.
     * @typedef {object} Product
     *
     * @property {string} id
     *  The id of the product
     *
     * @property {string} name
     *  Product name
     *
     * @property {Image} image
     *  Product Image Representation
     *
     * @property {object.<string, object>} fields
     *  Map containing field name as the key and it's field value inside an object.
     *
     * @property {Prices} prices
     *  Negotiated and listed price info
     */

    /**
     * A product image.
     * @typedef {object} Image
     *
     * @property {string} url
     *  The URL of an image.
     *
     * @property {string} title
     *  The title of the image.
     *
     * @property {string} alternativeText
     *  The alternative display text of the image.
     */

    /**
     * Prices associated to a product.
     *
     * @typedef {Object} Pricing
     *
     * @property {string} listingPrice
     *  Original price for a product.
     *
     * @property {string} negotiatedPrice
     *  Final price for a product after all discounts and/or entitlements are applied
     *  Format is a raw string without currency symbol
     *
     * @property {string} currencyIsoCode
     *  The ISO 4217 currency code for the product card prices listed
     */

    /**
     * Gets or sets the display data for card.
     *
     * @type {Product}
     */
    @api
    displayData;

    /**
     * Gets the product image.
     *
     * @type {Image}
     * @readonly
     * @private
     */
    get image() {
        // console.log(this.displayData);
        return this.displayData.image || {};
    }
    
    /**
     * Gets the product price.
     *
     * @type {string}
     * @readonly
     * @private
     */
    get price() {
        const prices = this.displayData.prices;
        return prices.negotiatedPrice || prices.listingPrice;
    }

    /**
     * Whether or not the product has price.
     *
     * @type {Boolean}
     * @readonly
     * @private
     */
    get hasPrice() {
        return !!this.price;
    }

    get hasQuantityRule() {
        return !!this.displayData.purchaseQuantityRule;
    }

    connectedCallback(){
        if (LOCALE === 'es-MX') {
            this.isMexico = true;
            this.getStockAvailabilityColor(this.displayData.fields.LB2BProductAvailabilityStatusMx__c.value);
        }
        if (LOCALE === 'fr-CA') {
            this.isCanada = true;
            this.getStockAvailabilityColor(this.displayData.fields.LB2BProductAvailabilityStatusCa__c.value);
        }
        if (LOCALE === 'en-US') {
            this.isUsa = true;
            this.getStockAvailabilityColor(this.displayData.fields.LB2BProductAvailabilityStatus__c.value);
        }    
    }

    //To check Stock Availability Color 
    getStockAvailabilityColor(field) {
        if (field === 'In Stock') {
            this.stockAvailabilityColor = 'item-in-stock flex-right-or-left'
        } else if (field === 'Out of Stock') {
            this.stockAvailabilityColor = 'item-out-stock flex-right-or-left'
        } else {
            this.stockAvailabilityColor = 'item-out-stock flex-right-or-left'
        }
    }


    /**
     * Emits a notification that the user wants to add the item to their cart.
     *
     * @fires SearchCard#calltoaction
     * @private
     */
    notifyAction() {
        this.dispatchEvent(
            new CustomEvent('calltoaction', {
                bubbles: true,
                composed: true,
                detail: {
                    productId: this.displayData.id,
                    productName: this.displayData.name
                }
            })
        );
    }

    /**
     * Emits a notification that the user indicates a desire to view the details of a product.
     *
     * @fires SearchCard#showdetail
     * @private
     */
    notifyShowDetail(evt) {
        productClick('select_item',this.displayData.name,this.displayData.fields.Brand__c.value,this.displayData.fields.StockKeepingUnit.value,null,this.displayData.prices.negotiatedPrice,null,this.displayData.prices.currencyIsoCode,this.displayData.index);
        evt.preventDefault();
        this.dispatchEvent(
            new CustomEvent('showdetail', {
                bubbles: true,
                composed: true,
                detail: { productId: this.displayData.id }
            })
        );
    }
}