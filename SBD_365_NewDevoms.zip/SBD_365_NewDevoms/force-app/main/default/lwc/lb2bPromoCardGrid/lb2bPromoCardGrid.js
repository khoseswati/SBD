import { LightningElement, api } from 'lwc';

export default class Lb2bPromoCardGrid extends LightningElement {
    @api
    displayData;

    //Portrait Image
    get imageAttribute() {
        return this.displayData.Content_Card_Image_Attribute__c;
    }
}