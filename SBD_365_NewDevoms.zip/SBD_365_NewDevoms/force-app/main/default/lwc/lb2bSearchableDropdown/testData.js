const TEST_DATA = [
    {
        value: 'soldTo|123',
        label: 'Hello, World',
        description: 'My world Jest!'
    },
    {
        value: 'soldTo|456',
        label: 'Henchmen Inc.',
        description: 'An evil organization'
    },
    {
        value: 'soldTo|789',
        label: 'Doctor Who',
        description: 'A good guy'
    }
];

export {
    TEST_DATA
}