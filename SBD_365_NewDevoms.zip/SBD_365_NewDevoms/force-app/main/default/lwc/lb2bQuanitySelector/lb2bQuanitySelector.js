import { LightningElement, api, wire,track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

import { publish, MessageContext } from 'lightning/messageService';
import cartChanged from '@salesforce/messageChannel/lightning__commerce_cartChanged';

import addToCart from '@salesforce/apex/LB2BQuantitySelectorController.addProductToCart';
import COMMUNITY_ID from '@salesforce/community/Id';

import LB2BQuickPrice from '@salesforce/label/c.LB2BSuccess';
import LB2BPLPAddedToCart from '@salesforce/label/c.LB2BPLPAddedToCart';
import LB2BGenericErrorTitle from '@salesforce/label/c.LB2BGenericErrorTitle';
import LB2BMinimum from '@salesforce/label/c.LB2BMinimum';
import LB2BAddToCart from '@salesforce/label/c.LB2BAddToCart';
import LB2BQuantity from '@salesforce/label/c.LB2BQuantity';
import LB2BLoading from '@salesforce/label/c.LB2BLoading';
import LB2BInvalidQuantity from '@salesforce/label/c.LB2BInvalidQuantity';
import {addtocartEvent} from 'c/lb2bDataLayer';
import getWishlistSummaries from '@salesforce/apex/LB2BCartController.getWishlistSummaries';
import createWishlist from '@salesforce/apex/LB2BCartController.createWishlist';
import addProductToWishlist from '@salesforce/apex/LB2BQuantitySelectorController.addProductToWishlist';
import { CurrentPageReference, NavigationMixin } from 'lightning/navigation';
import getProduct from '@salesforce/apex/LB2BGetUserInformation.getProduct';
import LB2BReorderInProgress from '@salesforce/label/c.LB2BReorderInProgress';
import LB2BViewCartPdp from '@salesforce/label/c.LB2BViewCartPdp';
import LB2BContinueShoppingPdp from '@salesforce/label/c.LB2BContinueShoppingPdp';
import LB2BAddToList from '@salesforce/label/c.LB2BAddToList';
import LB2BClose from '@salesforce/label/c.LB2BClose';
import LB2BCreateList from '@salesforce/label/c.LB2BCreateList';
import LB2BAddtoexistingList from '@salesforce/label/c.LB2BAddtoexistingList';
import LB2BListName from '@salesforce/label/c.LB2BListName';
import LB2BMyLists from '@salesforce/label/c.LB2BMyLists';
import LB2BCancel from '@salesforce/label/c.LB2BCancel';
import LB2BAdd from '@salesforce/label/c.LB2BAdd';

export default class Lb2bQuanitySelector extends NavigationMixin(LightningElement) {
    /**
     * @typedef {object} QuantityRule
     *
     * @property {number} minimum
     * @property {number} maximum
     * @property {number} increment
     */

    @api
    productId;

    @api
    effectiveAccountId;

    @api
    showAddToCart;

    @api 
    productName;

    @api
    productSku;

    @api
    productBrand;

    @api
    productPrice;

    @api
    productIsocode;

    @api
    productIndex;

    @wire(MessageContext)
    messageContext;

    value;

    isLoading = false;

    /** @type {QuantityRule} */
    _quantityRule;

    hasQuantityRule;
    disableCartButton;

    communityId = COMMUNITY_ID;

    labels = {
        LB2BQuickPrice,
        LB2BPLPAddedToCart,
        LB2BGenericErrorTitle,
        LB2BMinimum,
        LB2BAddToCart,
        LB2BQuantity,
        LB2BLoading,
        LB2BInvalidQuantity,
        LB2BReorderInProgress,
        LB2BViewCartPdp,
        LB2BContinueShoppingPdp,
        LB2BAddToList,
        LB2BClose,
        LB2BCreateList,
        LB2BAddtoexistingList,
        LB2BListName,
        LB2BMyLists,
        LB2BCancel,
        LB2BAdd
    };

    /** @type {QuantityRule} */
    get quantityRule() {
        if (!this.hasQuantityRule) {
            return {
                minimum: 1,
                increment: 1,
                maximum: Infinity
            };
        } else {
            return this._quantityRule;
        }
    }

    @api
    set quantityRule(value) {
        console.log('quantityRule: ', value);
        this._quantityRule = value;
        this.hasQuantityRule = !!value;
        console.log('hasQuantityRule: ', this.hasQuantityRule);

        if (this.hasQuantityRule) {
            this.value = this.quantityRule.minimum;
        } else {
            this.value = 1;
        }
    }

    handleQuantityDecrementtClick() {
        if (this.value - this.quantityRule.increment < this.quantityRule.minimum) {
            this.value = this.quantityRule.minimum;
        } else {
            this.value -= this.quantityRule.increment;
        }

        this.updateValidity();
    }

    handleQuantityIncrementClick() {
        if (this.value + this.quantityRule.increment > this.quantityRule.maximum) {
            this.value = this.quantityRule.maximum;
        } else {
            this.value += this.quantityRule.increment;
        }

        this.updateValidity();
    }

    updateValidity() {
        const quantityInput = this.template.querySelector('input');
        quantityInput.value = this.value;

        if (this.value % this.quantityRule.increment == 0) {
            quantityInput.setCustomValidity(labels.LB2BInvalidQuantity);
        } else {
            quantityInput.setCustomValidity('');
        }
    }

    handleInput(event) {
        const quantityInput = this.template.querySelector('input');
        const q = quantityInput.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');

        quantityInput.value = q;
    }

    handleQuantityChanged(event) {
        const quantityInput = this.template.querySelector('input');
        const q = quantityInput.value;

        const isValid =
            q >= this.quantityRule.minimum &&
            q <= this.quantityRule.maximum &&
            q % this.quantityRule.increment === 0;

        this.disableCartButton = !isValid;
        this.value = isValid ? q : this.value;

        this.updateValidity();

        // console.log(isValid, q, this.value);
    }

    handleAddToCart() {
        this.MoveToDataLayer();
        this.isLoading = true;
        console.log('this.productId: ', this.productId,'this.value ', this.value,'this.recordId ', this.recordId )
        if (this.isPDP !== false) {
            this.calladdToCart(this.recordId);
        } else {
            this.calladdToCart(this.productId);
        }
        console.log('this.productId:1111 ', this.productId);
        
    }

    calladdToCart(data) {
        addToCart({
            productId: data,
            quantity: this.value,
            communityId: this.communityId,
            accountId: this.effectiveAccountId
        })
            .then((result) => {
                console.log('result for cart id: ', result)
                this.isLoading = false;
                if (this.isPDP !== false) {
                    this.openModal = true;
                    this.cartId = result.cartId;
                    publish(this.messageContext, cartChanged);
                } else {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: this.labels.LB2BSuccess,
                            message: this.labels.LB2BPLPAddedToCart,
                            variant: 'success'
                        })
                    );

                    publish(this.messageContext, cartChanged);
                }
            })
            .catch((err) => {
                this.isLoading = false;
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: this.labels.LB2BGenericErrorTitle,
                        message: err,
                        variant: 'error'
                    })
                );
                console.error('err',err);
            });
    }


    MoveToDataLayer() {
        addtocartEvent('add_to_cart', this.productName, this.productBrand, this.productSku,null,this.productPrice,null, this.productIsocode,this.productIndex, this.value);
    }

    //Boolean tracked variable to indicate if modal is open or not default value is false as modal is closed when page is loaded
    @track isModalOpen = false;
    @track showExistingLists = false;
    /*Handle Radio button Change */
    @track createListValue = true;
    @track addToListValue = false;
    listname;
    wishlist;
    wishlistId;
    newWishlistId;
    data;
    existingListsLength;
    existingListName;
    existingLists;
    values;
    @api isPdp;
    @api recordId;
    @track openModal = false;
    cartId;
    @track productUrl;
    @track product_Name;
    @track list_Name;
    @track isCreateList = true;
    @track isExistingList = false;
    @track isdisabaled = false;

    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        this.recordId = currentPageReference.attributes.recordId;
    }


    connectedCallback() {
        console.log('label ', LB2BReorderInProgress)
        // this.getLists();

        if (this.isPdp !== 'false') {
            this.getLists();

            getProduct ({
                communityId: this.communityId,
                productId: this.recordId,
                effectiveAccountId: this.effectiveAccountId
            })
            .then((result) =>{
                console.log('result of getProduct: ', result)
                this.hasQuantityRule = result.purchaseQuantityRule;
                console.log('hasQuantity rule: ', this.hasQuantityRule);
                this.productUrl = result.defaultImage.url;
                this.product_Name = result.fields.Name;
                console.log('pathname: ',(result.primaryProductCategoryPath.path).slice(-1)[0]);
                console.log('pathname name-------->: ',(result.primaryProductCategoryPath.path).slice(-1)[0].name);
                this.listname = (result.primaryProductCategoryPath.path).slice(-1)[0].name;

                if (this.hasQuantityRule) {
                    
                } else {
                    this.value = 1;
                }
            })
            .catch((error) =>{
                console.log('error of getPorduct: ', error)
            })
            
        }
        
    }

    get isPDP(){
        if (this.isPdp == 'false'){
            return false;
        } else {
            return true;
        }
    }

    //Gets all the wishlist summaries if any
    getLists() {
        getWishlistSummaries({
            communityId : this.communityId,
            effectiveAccountId: this.effectiveAccountId
        }).then((result) => {
            this.data = JSON.parse(JSON.stringify(result));
            console.log('getWishlistSummaries: ', this.data)
            let listOption = [];

            this.existingListsLength = result.summaries.length;

            for (let i = 0; i < this.existingListsLength; i++) {
                this.existingListName = result.summaries[i].name;

                listOption.push({
                    label: this.existingListName
                        .replace('&amp;', '&')
                        .replace('&lt;/p&gt;', '')
                        .replace('&amp;amp;', '&')
                        .replace('&amp;#39;', "'"),
                    value: this.existingListName
                });
            }
            this.existingLists = listOption;
            //console.log("ExlistOptions:" ,JSON.parse(JSON.stringify(this.existingLists)));

            if (this.existingLists != 0) {
                this.showExistingLists = true;
            }
        });
    }

    get options() {
        return this.existingLists;
    }

    handleRadioChange(event) {
        let selectedOption = event.target.value;
        if (selectedOption == 'createList') {
            this.isCreateList = true;
            this.isExistingList = false;
            this.isdisabaled = this.listname != null || this.listname != undefined ? false : true;

        }else if (selectedOption == 'addToList') {
            this.isCreateList = false;
            this.isExistingList = true;
            this.isdisabaled = this.values != null || this.values != undefined ? false : true;
        }
    }

    /*Handle Existing Lists Dropdown*/
    handleExistingLists(event) {
        alert('existing list')
        this.values = event.detail.value;
        console.log('handle onchange : ', this.value);
        this.isExistingList = true;
        this.isCreateList = false;
        this.isdisabaled = this.values != null || this.values != undefined ? false : true;
    }

    //Handle Create new list 
    handleCreateNewList(event){
        if (event.detail.value != undefined){
            this.listname += event.detail.value;
        } else {
            this.listname = this.listname;
            
        }
        
        this.isExistingList = false;
        this.isCreateList = true;
        this.isdisabaled = this.listname != null || this.listname != undefined ? false : true;
        
    }

    // Add to list method 
    openModalForList(){
        console.log('add to list');
        this.isModalOpen = true;
    }

    closeModalForList() {
        // to close modal set isModalOpen track value as false
        this.isModalOpen = false;
        this.openModal = false;
    }

    goToCartPage(){
        let url = window.location.origin+'/tc/s/cart/'+this.cartId;
        this.navigateToWebPage(url);
    }

    navigateToWebPage(url) {
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: url
            }
        });
    }

    handleCreateList() {
        this.isModalOpen = false;

        // if (this.createListValue == true) {
        if (this.isCreateList) {
            alert('new list')
            this.listname = this.template.querySelector(`[data-id = "newlist"]`).value;
            console.log('this.listname: ', this.listname);
            createWishlist({
                communityId : this.communityId,
                effectiveAccountId: this.effectiveAccountId,
                listname: this.listname
            })
                .then((result) => {
                    this.wishlist = result.summary;
                    this.newWishlistId = result.summary.id;

                    addProductToWishlist({
                        communityId : this.communityId,
                        effectiveAccountId: this.effectiveAccountId,
                        wishlistId: this.newWishlistId,
                        productId: this.recordId
                    })
                        .then((result) => {
                            console.log('Add Item To List:', result);
                            this.dispatchEvent(
                                new ShowToastEvent({
                                    // title: this.label.LB2BSuccess,
                                    message: 'Product Added to Wishlist',
                                    variant: 'success',
                                    mode: 'dismissable'
                                })
                            );
                        })
                        .catch((error) => {
                            // let message = this.label.LB2BOrderDetailError;
                            console.log('Error Msg new list:', error);

                            // this.dispatchEvent(
                            //     new ShowToastEvent({
                            //         title: 'Error',
                            //         message: message,
                            //         variant: 'error',
                            //         mode: 'dismissable'
                            //     })
                            // );
                        });
                })
                .catch((error) => {
                    let message = error.body.message;
                    console.log('Error Msg:', message);

                    this.dispatchEvent(
                        new ShowToastEvent({
                            // title: this.label.LB2BError,
                            message: message,
                            variant: 'error',
                            mode: 'dismissable'
                        })
                    );
                });
        }

        // if (this.addToListValue == true) {
        if (this.isExistingList) {
            alert('existing list')
            let existingName = this.template.querySelector(`[data-id = "existinglist"]`).value;

            let id;
            for (let i = 0; i < this.existingListsLength; i++) {
                if (this.data.summaries[i].name == existingName) {
                    id = this.data.summaries[i].id;
                }
            }
            this.wishlistId = id;
            console.log('WishlistId: ', this.wishlistId);

            addProductToWishlist({
                communityId : this.communityId,
                effectiveAccountId: this.effectiveAccountId,
                wishlistId: this.wishlistId,
                productId: this.recordId
            })
                .then((result) => {
                    console.log('Add Item To Existing List:', result);
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Success',
                            message: 'Products Added to Wishlist',
                            variant: 'success',
                            mode: 'dismissable'
                        })
                    );
                })
                .catch((error) => {
                    // let message = this.label.LB2BOrderDetailError;
                    console.log('Error Msg:', error);

                    // this.dispatchEvent(
                    //     new ShowToastEvent({
                    //         title: this.label.LB2BError,
                    //         message: message,
                    //         variant: 'error',
                    //         mode: 'dismissable'
                    //     })
                    // );
                });
        }
    }
}