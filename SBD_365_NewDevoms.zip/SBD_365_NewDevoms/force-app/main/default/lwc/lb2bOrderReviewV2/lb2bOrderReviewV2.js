/**
 * This component display the Account details, shipping addrss, total number of cart items
 * and total amount of product to place the order.
 */

import getOrderNo from '@salesforce/apex/LB2BCallEnosix.getOrderNo';
import getSapAccountFlags from '@salesforce/apex/LB2BCartController.getSapAccountFlags';
import getSapTotal from '@salesforce/apex/LB2BCartController.getSapTotal';
import communityId from '@salesforce/community/Id';
import CurrencyCode from '@salesforce/i18n/currency';
import LOCALE from '@salesforce/i18n/locale';
import CurrencyFormat from '@salesforce/i18n/number.currencyFormat';
import LB2BCartTimeOutErrorMsg from '@salesforce/label/c.LB2BCartTimeOutErrorMsg';
import LB2BDropShipAddress from '@salesforce/label/c.LB2BDropShipAddress';
import LB2BEditCart from '@salesforce/label/c.LB2BEditCart';
import LB2BFreight from '@salesforce/label/c.LB2BFreight';
import LB2BLiftFee from '@salesforce/label/c.LB2BLiftFee';
import LB2BLoading from '@salesforce/label/c.LB2BLoading';
import LB2BLoadingCartItems from '@salesforce/label/c.LB2BLoadingCartItems';
import LB2BOrderCreationFail from '@salesforce/label/c.LB2BOrderCreationFail';
import LB2BOrderDate from '@salesforce/label/c.LB2BOrderDate';
import LB2BOrderDetails from '@salesforce/label/c.LB2BOrderDetails';
import LB2BOrderReview from '@salesforce/label/c.LB2BOrderReview';
import LB2BOrderSumm from '@salesforce/label/c.LB2BOrderSumm';
import LB2BPackingDeliveryInstructions from '@salesforce/label/c.LB2BPackingDeliveryInstructions';
import LB2BPlaceOrder from '@salesforce/label/c.LB2BPlaceOrder';
import LB2BPONumber from '@salesforce/label/c.LB2BPONumber';
import LB2BProceedToCart from '@salesforce/label/c.LB2BProceedToCart';
import LB2BResidentialFee from '@salesforce/label/c.LB2BResidentialFee';
import LB2BSapAccount from '@salesforce/label/c.LB2BSapAccount';
import LB2BSavings from '@salesforce/label/c.LB2BSavings';
import LB2BShip_To from '@salesforce/label/c.LB2BShip_To';
import LB2BSold_To from '@salesforce/label/c.LB2BSold_To';
import LB2BSubtotal from '@salesforce/label/c.LB2BSubtotal';
import LB2BTotal from '@salesforce/label/c.LB2BTotal';
import LB2BCheckout from '@salesforce/label/c.LB2BCheckout';

import { toastUtil } from 'c/lb2bUtil';
import { CurrentPageReference, NavigationMixin } from 'lightning/navigation';
import { LightningElement, wire, api, track } from 'lwc';
import LB2BMultipleLocation from '@salesforce/label/c.LB2BMultipleLocation';

// Event name constants
const CART_CHANGED_EVT = 'cartchanged';

export default class lb2bOrderReviewV2 extends NavigationMixin(LightningElement) {
    @track total = [];
    @track error;
    @api testvar;
    @api recordId;
    @api effectiveAccountId;
    pageParam = null;
    //  pageSize = 100;
    sortParam = 'CreatedDateDesc';
    cartItems;
    @track subTotal;
    @track freight;
    @track residentialFreightFee;
    @track liftGateFee;
    @track total;
    @track savings;
    @api displayTotal;
    @api _poNumber = '';
    @api ensxb2b__sap_BillTo_PartnerNumber;
    @api ensxb2b__sap_DeliverTo_PartnerNumber;
    @api cartIdFromLocalStorage;
    @api getTodaysDate;
    @api SoldtoAccountname;
    @api accountName;
    @api ShippingStreet;
    @api ShippingCity;
    @api ShippingState;
    @api ShippingCountry;
    @api ShippingPostalCode;
    @api orderNumber;
    @api orderDetails;
    @api disabled = false;
    isLoader = false;
    @api showDropShip = false;
    @api dropShipAddress1;
    @api dropShipAddress2;
    @api dropShipCity;
    @api dropShipState;
    @api dropShipZip;
    @api dropShipCountry;
    @api layoutSize = '4';
    @track showAddress2;
    @track checkShowDropShip;
    @api openModal;
    @api showPackingInstructions;
    @api packingInstructions;

    @track isMultipleLocation = false;

    doShowFreightFields;

    @track soldToStreet;
    @track soldToCity;
    @track soldToState;
    @track soldToCountry;
    @track soldToPostalCode;

    /**
     * An object with the current PageReference.
     * This is needed for the pubsub library.
     *
     * @type {PageReference}
     *
     *  @property {number} sapOrderQuantity
     *   The quantity of the cart item.
     */

    @wire(CurrentPageReference)
    pageRef;

    /**
     * Total number of items in the cart
     * @private
     * @type {Number}
     */
    _cartItemCount = 0;

    label = {
        LB2BEditCart,
        LB2BOrderDetails,
        LB2BOrderDate,
        LB2BPONumber,
        LB2BSold_To,
        LB2BShip_To,
        LB2BOrderSumm,
        LB2BSubtotal,
        LB2BFreight,
        LB2BResidentialFee,
        LB2BLiftFee,
        LB2BTotal,
        LB2BSavings,
        LB2BOrderReview,
        LB2BPlaceOrder,
        LB2BSapAccount,
        LB2BDropShipAddress,
        LB2BOrderCreationFail,
        LB2BLoading,
        LB2BLoadingCartItems,
        LB2BCartTimeOutErrorMsg,
        LB2BProceedToCart,
        LB2BPackingDeliveryInstructions,
        LB2BCheckout,
        LB2BMultipleLocation
    };

    intl = {
        CurrencyCode,
        CurrencyFormat
    };

    get todaysDate() {
        var today = new Date();
        today = new Intl.DateTimeFormat(LOCALE).format(today);
        this.getTodaysDate = today;
        return today;
    }

    _connectedResolver;
    _canResolveUrls = new Promise((resolved) => {
        this._connectedResolver = resolved;
    });

    connectedCallback() {
        //To show/hide dropShip Address in orderConfirmation page
        this.checkShowDropShip = localStorage.getItem('checkbox');

        if (this.checkShowDropShip == 'true') {
            this.showDropShip = true;
            this.layoutSize = '3';
        }

        // To get cart items data from localstorage
        this.cartItems = JSON.parse(localStorage.getItem('cartItems'));
        this.resetTimer();

        this.cartIdFromLocalStorage = localStorage.getItem('cartId');
        this.packingInstructions = localStorage.getItem('packing');
        this.updateCartItems();
        this._connectedResolver();

        //To show/hide the packingSlip Instructions
        // this.packingInstructions = localStorage.getItem('packing');
        console.log('Packing Instructions: ', this.packingInstructions);
        if (this.packingInstructions != 'undefined' && this.packingInstructions != '') {
            this.showPackingInstructions = true;
        }
    }

    navigateToCart() {
        let url = window.location.origin + window.location.pathname;
        // let newUrl = url.replace(/order-review/, 'cart/');
        let newUrl = url.replace(/checkout/, 'cart/');
        let cartUrl = newUrl + this.cartIdFromLocalStorage;
        console.log('url', newUrl + this.cartIdFromLocalStorage);
        this.navigateToCartPage(cartUrl);
    }

    navigateToCartPage(url) {
        console.log(url);
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: url
            }
        });
    }

    navigateToOrderConfirmation() {
        this.disabled = true;
        this.updateOrderDetails();
    }

    //get the reference number for order confirmation page
    updateOrderDetails() {
        this.isLoader = true;
        console.log('cartid:', this.cartIdFromLocalStorage);
        getOrderNo({
            cartId: this.cartIdFromLocalStorage
        }).then((result) => {
            if (result != undefined) {
                this.orderDetails = result;
                console.log('result of order no: ', this.orderDetails);
                this.orderNumber = this.orderDetails.data.orderNumber;
                console.log('order review order number : ', this.orderNumber);
                if (result.isSuccess) {
                    this.isLoader = false;
                    this.handleCartUpdate();
                    this.getUrl();
                } else {
                    this.navigateToCart();
                    toastUtil.toastError(this, { message: LB2BOrderCreationFail });
                }
            }
        });
    }

    getUrl() {
        let url = window.location.origin + window.location.pathname;
        console.log('window url', url);
        // let newUrl = url.replace(/order-review/, 'orderconfirmation/');
        let newUrl = url.replace(/checkout/, 'orderconfirmation/');
        let cartUrl = newUrl + this.cartIdFromLocalStorage;
        this.navigateToOrderConfirmationPage(cartUrl);
    }

    navigateToOrderConfirmationPage(url) {
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: url + '?orderNumber=' + this.orderNumber
            }
        });
    }

    handleCartUpdate() {
        console.log('updating Cart Badge ');
        // Update Cart Badge
        this.dispatchEvent(
            new CustomEvent(CART_CHANGED_EVT, {
                bubbles: true,
                composed: true
            })
        );

        // Notify any other listeners that the cart items have updated
        // fireEvent(this.pageRef, CART_ITEMS_UPDATED_EVT);
    }

    get resolvedEffectiveAccountId() {
        const effectiveAccountId = this.effectiveAccountId || '';
        let resolved = null;
        if (effectiveAccountId.length > 0 && effectiveAccountId !== '000000000000000') {
            resolved = effectiveAccountId;
        }
        return resolved;
    }

    get isCartItemListIndeterminate() {
        return !Array.isArray(this.cartItems);
    }

    updateCartItems() {
        getSapTotal({
            webcartId: this.cartIdFromLocalStorage
        })
            .then((result) => {
                console.log('Get SAP Total:', result);
                this._poNumber = result[0].UI_Po_Number__c;
                console.log('sold to  NO: ', result[0].ensxb2b__sap_BillTo_PartnerNumber__c);
                this.ensxb2b__sap_BillTo_PartnerNumber =
                    result[0].ensxb2b__sap_BillTo_PartnerNumber__c;

                this.ensxb2b__sap_DeliverTo_PartnerNumber =
                    result[0].ensxb2b__sap_DeliverTo_PartnerNumber__c;

                this.SoldtoAccountname = result[0].Sold_To_SAP_Account__r.Name;
                this.soldToStreet = result[0].Sold_To_SAP_Account__r.Street__c;
                this.soldToCity = result[0].Sold_To_SAP_Account__r.City__c;
                this.soldToState = result[0].Sold_To_SAP_Account__r.State__c;
                this.soldToPostalCode = result[0].Sold_To_SAP_Account__r.Postal_Code__c;
                this.soldToCountry = result[0].Sold_To_SAP_Account__r.Country__c;
                if(result[0].Ship_To_SAP_Account__r != undefined) {
                    this.accountName = result[0].Ship_To_SAP_Account__r.Name;
                    this.ShippingStreet = result[0].Ship_To_SAP_Account__r.Street__c;
                    this.ShippingCity = result[0].Ship_To_SAP_Account__r.City__c;
                    this.ShippingState = result[0].Ship_To_SAP_Account__r.State__c;
                    // this.ShippingState = result[0].Ship_To_SAP_Account__r.City__c ;
                    this.ShippingPostalCode = result[0].Ship_To_SAP_Account__r.Postal_Code__c;
                    this.ShippingCountry = result[0].Ship_To_SAP_Account__r.Country__c;
                } else {
                    this.isMultipleLocation = true;
                    this.accountName = LB2BMultipleLocation;
                }
                this.displayTotal = result[0];

                this.subTotal = parseFloat(result[0].LB2B_SubTotal__c).toFixed(2);
                this.freight = parseFloat(result[0].Freight__c).toFixed(2);
                this.residentialFreightFee = parseFloat(
                    result[0].Residential_Freight_Fee__c
                ).toFixed(2);
                this.liftGateFee = parseFloat(result[0].Lift_Gate_Fee__c).toFixed(2);
                this.total = parseFloat(result[0].LB2B_Total__c).toFixed(2);
                this.savings = parseFloat(result[0].LB2B_Savings__c).toFixed(2);

                //To display fields on dropShipAddress
                if (result.length != 0) {
                    this.dropShipAddress1 = result[0].SAP_ShipTo_Override_Street__c;
                    this.dropShipAddress2 = result[0].SAP_ShipTo_Override_Street2__c;
                    this.dropShipCity = result[0].SAP_ShipTo_Override_City__c;
                    //this.dropShipState = result[0].LB2BState__c;
                    this.dropShipState = result[0].SAP_ShipTo_Override_Region__c;
                    this.dropShipZip = result[0].SAP_ShipTo_Override_PostalCode__c;
                    this.dropShipCountry = result[0].SAP_ShipTo_Override_Country__c;

                    if (this.dropShipAddress2 != undefined) {
                        this.showAddress2 = true;
                    }
                }

                getSapAccountFlags({ sapAccountId: result[0].Sold_To_SAP_Account__c })
                    .then((accountResult) => {
                        console.log('Currency:', accountResult[0].CurrencyIsoCode);
                        if (accountResult.length == 0) {
                            this.doShowFreightFields = true;
                        } else {
                            if (accountResult[0].CurrencyIsoCode == 'USD') {
                                this.doShowFreightFields = true;
                            } else {
                                this.doShowFreightFields = false;
                            }
                        }
                    })
                    .catch((err) => {
                        console.error(err);
                    });
            })
            .catch((error) => {
                console.error(error);
            });
    }

    resetTimer() {
        clearTimeout(this.timeoutId);
        this.timeoutId = setTimeout(() => {
            this.sessionExpirationModal();
        }, 900000);
    }

    sessionExpirationModal() {
        this.openModal = true;
    }

    handleNewCart() {
        createCart({
            communityId,
            effectiveAccountId: this.resolvedEffectiveAccountId
        })
            .then((result) => {
                console.log('Created New Cart');
            })
            .catch((error) => {
                console.log('Error in Handle New Cart:', error);
            });
    }
}