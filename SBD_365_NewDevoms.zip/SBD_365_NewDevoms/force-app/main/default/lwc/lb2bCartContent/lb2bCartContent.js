/**
 * To display the cart items in cart page using child component LB2B_CART_cartItem.
 * 
 * lb2bCartContent is parent of LB2B_CART_cartItem component.
 * 
 * To display Account details and shipping address in cart page.
 * 
 */

import { api, wire, track, LightningElement } from 'lwc';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import { registerListener } from 'c/lb2bPubSub';

import communityId from '@salesforce/community/Id';
import getCartItems from '@salesforce/apex/LB2BCartController.getCartItems';
import updateCartItem from '@salesforce/apex/LB2BCartController.updateCartItem';
import deleteCartItem from '@salesforce/apex/LB2BCartController.deleteCartItem';
import deleteCart from '@salesforce/apex/LB2BCartController.deleteCart';
import createCart from '@salesforce/apex/LB2BCartController.createCart';
import getCartItemDetails from '@salesforce/apex/LB2BOrderTypeSelectorController.getCartItemDetails';
import getOrderDetails from '@salesforce/apex/LB2BOrderTypeSelectorController.getOrderDetails';
import getWishlistSummaries from '@salesforce/apex/LB2BCartController.getWishlistSummaries';
import createWishlist from '@salesforce/apex/LB2BCartController.createWishlist';
import copyCartToWishlist from '@salesforce/apex/LB2BCartController.copyCartToWishlist';
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import { fireEvent } from 'c/lb2bPubSub';
import { isCartClosed } from 'c/lb2bCartUtils';
import LB2BShip_To from '@salesforce/label/c.LB2BShip_To';
import LB2BAccount from '@salesforce/label/c.LB2BAccount';
import LB2BQuick_Orders from '@salesforce/label/c.LB2BQuick_Orders';
import LB2BCartHeader from '@salesforce/label/c.LB2BCartHeader';
import LB2BAdd_All_List from '@salesforce/label/c.LB2BAdd_All_List';
import LB2BClear_Cart from '@salesforce/label/c.LB2BClear_Cart';
import LB2BClosedCartLabel from '@salesforce/label/c.LB2BClosedCartLabel';
import LB2BEmptyCartHeaderLabel from '@salesforce/label/c.LB2BEmptyCartHeaderLabel';
import LB2BFooter_Line from '@salesforce/label/c.LB2BFooter_Line';
import LB2BClose from '@salesforce/label/c.LB2BClose';
import LB2BCreateList from '@salesforce/label/c.LB2BCreateList';
import LB2BAddtoexistingList from '@salesforce/label/c.LB2BAddtoexistingList';
import LB2BCancel from '@salesforce/label/c.LB2BCancel';
import LB2BAdd from '@salesforce/label/c.LB2BAdd';
import LB2BClearAll from '@salesforce/label/c.LB2BClearAll';
import LB2BRemoveall_Items from '@salesforce/label/c.LB2BRemoveall_Items';
import LB2BLoadingCartItems from '@salesforce/label/c.LB2BLoadingCartItems';
import LB2BError from '@salesforce/label/c.LB2BError';
import LB2BSuccess from '@salesforce/label/c.LB2BSuccess';
import LB2BProductsWishlistMsg from '@salesforce/label/c.LB2BProductsWishlistMsg';
import LB2BInvalidQuantity from '@salesforce/label/c.LB2BInvalidQuantity';
import LB2BQtyMsg2 from '@salesforce/label/c.LB2BQtyMsg2';
import LB2BQtyMsg1 from '@salesforce/label/c.LB2BQtyMsg1';
import LB2BGenericMessage from '@salesforce/label/c.LB2BGenericMessage';
import LB2BCustomerSupport from '@salesforce/label/c.LB2BCustomerSupport';
import LB2BPopError from '@salesforce/label/c.LB2BPopError';
import LB2BFinishedGoodsError from '@salesforce/label/c.LB2BFinishedGoodsError';
import LB2BMailID from '@salesforce/label/c.LB2BMailID';
import { getRecord, getFieldValue, updateRecord } from "lightning/uiRecordApi";
import Name from "@salesforce/schema/User.Account.Name";
import ShippingStreet from '@salesforce/schema/User.Account.ShippingStreet';
import ShippingCity from '@salesforce/schema/User.Account.ShippingCity';
import ShippingState from '@salesforce/schema/User.Account.ShippingState';
import ShippingCountry from '@salesforce/schema/User.Account.ShippingCountry';
import ShippingPostalCode from '@salesforce/schema/User.Account.ShippingPostalCode';
import USER_ID from "@salesforce/user/Id";
import SAP_CustomerNumber from '@salesforce/schema/User.Account.SAP_Customer_Number__c';
import Brand_Name from '@salesforce/schema/User.Account.Search_Term_2__c';
import LB2BLoading from '@salesforce/label/c.LB2BLoading';
// import LB2BPcrCodeFormat from '@salesforce/label/c.LB2BPcrCodeFormat';
import LB2BPcrCodes from '@salesforce/label/c.LB2BPcrCodes';
import LB2BPcrNotes from '@salesforce/label/c.LB2BPcrNotes';
import LB2BPcrNotesMin from '@salesforce/label/c.LB2BPcrNotesMin';

import LB2BContact_Us from '@salesforce/label/c.LB2BContact_Us';
import LOCALE from '@salesforce/i18n/locale';
import hasPermission from '@salesforce/customPermission/Internal_Sales_Rep';
import hasExportAffiliateUser from '@salesforce/customPermission/Export_Affiliate_User';
import hasDomesticAffiliate from '@salesforce/customPermission/Domestic_Affiliate_User';

// webcart fields related to ptomotion codes

import ID_FIELD from '@salesforce/schema/WebCart.Id';
import ORDERTYPEPICKLIST from '@salesforce/schema/WebCart.LB2BOrderType__c';
import PCRCode_1 from '@salesforce/schema/WebCart.PCR_Code_1__c';
import PCRCode_2 from '@salesforce/schema/WebCart.PCR_Code_2__c';
import PCRCode_3 from '@salesforce/schema/WebCart.PCR_Code_3__c';
import PCRCode_4 from '@salesforce/schema/WebCart.PCR_Code_4__c';
import PCRCode_5 from '@salesforce/schema/WebCart.PCR_Code_5__c';
import PCR_Notes from '@salesforce/schema/WebCart.PCR_Notes__c';

// Event name constants
const CART_CHANGED_EVT = 'cartchanged';
const CART_ITEMS_UPDATED_EVT = 'cartitemsupdated';

// Locked Cart Status
const LOCKED_CART_STATUSES = new Set(['Processing', 'Checkout']);


/**
 * A sample cart contents component.
 * This component shows the contents of a buyer's cart on a cart detail page.
 * When deployed, it is available in the Builder under Custom Components as
 * 'B2B Sample Cart Contents Component'
 *
 * @fires CartContents#cartchanged
 * @fires CartContents#cartitemsupdated
 */


export default class lb2bCartContent extends NavigationMixin(LightningElement) {

    @track customFormModal = false;
    @track isLoading =false;

    customHideModalPopup() {

        this.customFormModal = false;
    }
    label = {
        LB2BShip_To,
        LB2BAccount,
        LB2BQuick_Orders,
        LB2BCartHeader,
        LB2BAdd_All_List,
        LB2BClear_Cart,
        LB2BClosedCartLabel,
        LB2BFooter_Line,
        LB2BEmptyCartHeaderLabel,
        LB2BClose,
        LB2BCreateList,
        LB2BAddtoexistingList,
        LB2BCancel,
        LB2BAdd,
        LB2BClearAll,
        LB2BRemoveall_Items,
        LB2BLoading,
        LB2BLoadingCartItems,
        LB2BQtyMsg1,
        LB2BQtyMsg2,
        LB2BError,
        LB2BInvalidQuantity,
        LB2BSuccess,
        LB2BProductsWishlistMsg,
        LB2BGenericMessage,
        LB2BMailID,
        LB2BCustomerSupport,
        LB2BPopError,
        LB2BFinishedGoodsError,
        // LB2BPcrCodeFormat,
        LB2BPcrCodes,
        LB2BPcrNotes,
        LB2BPcrNotesMin
    };
    /**
     * An event fired when the cart changes.
     * This event is a short term resolution to update the cart badge based on updates to the cart.
     *
     * @event CartContents#cartchanged
     *
     * @type {CustomEvent}
     *
     * @export
     */

    /**
     * An event fired when the cart items change.
     * This event is a short term resolution to update any sibling component that may want to update their state based
     * on updates in the cart items.
     *
     * In future, if LMS channels are supported on communities, the LMS should be the preferred solution over pub-sub implementation of this example.
     * For more details, please see: https://developer.salesforce.com/docs/component-library/documentation/en/lwc/lwc.use_message_channel_considerations
     *
     * @event CartContents#cartitemsupdated
     * @type {CustomEvent}
     *
     * @export
     */

    /**
     * A cart line item.
     *
     * @typedef {Object} CartItem
     *
     * @property {ProductDetails} productDetails
     *   Representation of the product details.
     *
     * @property {number} quantity
     *   The quantity of the cart item.
     *
     * @property {string} originalPrice
     *   The original price of a cart item.
     *
     * @property {string} salesPrice
     *   The sales price of a cart item.
     *
     * @property {string} totalPrice
     *   The total sales price of a cart item, without tax (if any).
     *
     * @property {string} totalListPrice
     *   The total original (list) price of a cart item.
     * 
     * @property {string} workFlowId
     */

    /**
     * Details for a product containing product information
     *
     * @typedef {Object} ProductDetails
     *
     * @property {string} productId
     *   The unique identifier of the item.
     *
     * @property {string} sku
     *  Product SKU number.
     *
     * @property {string} name
     *   The name of the item.
     *
     * @property {ThumbnailImage} thumbnailImage
     *   The quantity of the item.
     */

    /**
     * Image information for a product.
     *
     * @typedef {Object} ThumbnailImage
     *
     * @property {string} alternateText
     *  Alternate text for an image.
     *
     * @property {string} id
     *  The image's id.
     *
     * @property {string} title
     *   The title of the image.
     *
     * @property {string} url
     *   The url of the image.
     */

    /**
     * Representation of a sort option.
     *
     * @typedef {Object} SortOption
     *
     * @property {string} value
     * The value for the sort option.
     *
     * @property {string} label
     * The label for the sort option.
     */

    /**
     * The recordId provided by the cart detail flexipage.
     *
     * @type {string}
     */
    @api
    recordId;

    /**
     * The effectiveAccountId provided by the cart detail flexipage.
     *
     * @type {string}
     */
    @api
    effectiveAccountId;


    /**
     * An object with the current PageReference.
     * This is needed for the pubsub library.
     *
     * @type {PageReference}
     */
    @wire(CurrentPageReference)
    pageRef;

    /**
     * Total number of items in the cart
     * @private
     * @type {Number}
     */
    _cartItemCount = 0;

    /**
     * A list of cartItems.
     *
     * @type {CartItem[]}
     */
    cartItems;

    /**
     * A wishlist summary.
     * @type {wishlist[]}
     */
    wishlist;

    /**
     * Name of the new wishlist
     * @type {String}
     */
    listname;

    /**
      * A NewWishlist Id
      * @type {String}
      */
    newWishlistId;

    /**
     * An Existing Wishlist Id
     * @type {String}
     */
    wishlistId;

    /**
     * An existing Wishlist Name
     * @type {String}
     */
    existingListName;

    // @track disabled= false;

    @track existingLists = [];
    errorMsg = [];
    @api isError = false;
    @track error;
    @track isModalOpen = false;
    @track createListValue = true;
    @track addToListValue = false;
    @track showExistingLists = false;
    data;
    @api _records;
    @api nextPageToken;
    @api previousPageToken;
    @api isLastItemDeleted = false;
    @track hidePagination;
    popProduct = false;
    fgProduct = false;
    popProducts=[];
    fgProducts=[];
   _isTargetedorPopFunds;
    ordertype;
    mailID;
    pcrcodes = [];
    pcrvaldiated = false;
    pcrNotes;
    isEmpty;
    isPcrNotes = false;
    pcrObj = {};

    // for work flow id functionality 
    newupdatedCartItems;


    /**
    * Representation of a  option.
    *
    * @typedef {Object} option
    *  *
    * @property {string} label
    * The label for the  option.
    *
    * @property {string} value
    * The value for the  option.
   
    */

    /**
     * A list of options useful for displaying options
     *
     * @type {option[]}
     */

    /**
    * Length of Wishlist Summaries
    * @type {Number}
    */
    existingListsLength;

    /**
     * Specifies the page token to be used to view a page of cart information.
     * If the pageParam is null, the first page is returned.
     * @type {null|string}
     */
    pageParam = null;
    @api pageSize = 100;

    /**
     * Sort order for items in a cart.
     * The default sortOrder is 'CreatedDateDesc'
     *    - CreatedDateAsc—Sorts by oldest creation date
     *    - CreatedDateDesc—Sorts by most recent creation date.
     *    - NameAsc—Sorts by name in ascending alphabetical order (A–Z).
     *    - NameDesc—Sorts by name in descending alphabetical order (Z–A).
     * @type {string}
     */
    sortParam = 'CreatedDateAsc';

    /**
     * Is the cart currently disabled.
     * This is useful to prevent any cart operation for certain cases -
     * For example when checkout is in progress.
     * @type {boolean}
     */
    isCartClosed = false;

    /**
     * The ISO 4217 currency code for the cart page
     *
     * @type {string}
     */
    currencyCode;

    /**
     * Gets whether the cart item list is empty.
     *
     * @type {boolean}
     * @readonly
     */
    get isCartEmpty() {
        // If the items are an empty array (not undefined or null), we know we're empty.
        return Array.isArray(this.cartItems) && this.cartItems.length === 0;
    }

  
    /**
     * Gets the cart header along with the current number of cart items
     *
     * @type {string}
     * @readonly
     * @example
     * 'Cart (3)'
     * ${this.labels.cartHeader}
     */
    get cartHeader() {
        return `(${this._cartItemCount})`;
    }

    /**
     * Gets whether the item list state is indeterminate (e.g. in the process of being determined).
     *
     * @returns {boolean}
     * @readonly
     */
    get isCartItemListIndeterminate() {
        return !Array.isArray(this.cartItems);
    }

    /**
     * Gets the normalized effective account of the user.
     *
     * @type {string}
     * @readonly
     * @private
     */
    get resolvedEffectiveAccountId() {
        const effectiveAccountId = this.effectiveAccountId || '';
        let resolved = null;
        if (
            effectiveAccountId.length > 0 &&
            effectiveAccountId !== '000000000000000'
        ) {
            resolved = effectiveAccountId;
        }
        return resolved;
    }

    /**
     * This lifecycle hook fires when this component is inserted into the DOM.
     */
    connectedCallback() {

        registerListener('sapcallFail', this.handleEvent, this);
        registerListener('paginationNextPage', this.handleNextPage, this);
        registerListener('paginationPreviousPage', this.handlePreviousPage, this);
        registerListener('InternalSalesCheck', this.showHideWorkflowId, this);
        registerListener('isTargetedorPopFunds', this.isTargetedorPopFunds, this);
        //registerListener('pcrvalidation', this.isPcrValidation, this);
        // Initialize 'cartItems' list as soon as the component is inserted in the DOM.
        localStorage.setItem('cartId', this.recordId);
        this.getLists();
        this.callgetCartItemDetails();
        this.callCartDetails();
        
        if(LOCALE === 'es-MX'){
           this.mailID = 'mailto:servicioalcliente@sbdinc.com';
        }
        if(LOCALE === 'fr-CA'){
           this.mailID = 'mailto:CDNtoolc@sbdinc.com';
        }
        if(LOCALE === 'en-US'){
            alert('locale >>> ',LOCALE);
           this.mailID = 'mailto:toolcommerceinquiry@sbdinc.com';
        }

        if(hasExportAffiliateUser){
            this.ordertype = 'LB2BExportAffiliate';
            this.updateOrderTypeRecords();
        }

        if(hasDomesticAffiliate){
            this.ordertype = 'LB2BDomesticAffiliates';
            this.updateOrderTypeRecords();
            console.log("this.ordertype",this.ordertype);
        }
    }

    callCartDetails(){
        getOrderDetails ({
            webcartId: this.recordId
        }).then(result => {
             this.pcrcodes[0] = result[0].PCR_Code_1__c !== undefined 
                                                        ? result[0].PCR_Code_1__c
                                                        : '';
             this.pcrcodes[1] = result[0].PCR_Code_2__c !== undefined 
                                                        ? result[0].PCR_Code_2__c
                                                        : '';   
             this.pcrcodes[2] = result[0].PCR_Code_3__c !== undefined 
                                                        ? result[0].PCR_Code_3__c
                                                        : '';   
             this.pcrcodes[3] = result[0].PCR_Code_4__c !== undefined 
                                                        ? result[0].PCR_Code_4__c
                                                        : '';                 
             this.pcrcodes[4] = result[0].PCR_Code_5__c !== undefined 
                                                        ? result[0].PCR_Code_5__c
                                                        : '';  
             this.pcrNotes = result[0].PCR_Notes__c !== undefined 
                                                        ? result[0].PCR_Notes__c
                                                        : '';
            this.pcrNotesValidation();
         })
         .catch(error => {
            console.log('error of get cart details ', error)
         })
    }

        callgetCartItemDetails() {
            getCartItemDetails({
                webcartId: this.recordId
            })
            .then(result => {
                console.log('result of get cart item details ', result)
                this.newupdatedCartItems = result;
                this.updateCartItems();

            })
            .catch(error => {
                console.log('error of get cart item details ', error)
            })


        }
        
    isTargetedorPopFunds(data) {
        this._isTargetedorPopFunds = data; 
        this.fgProducts=[];
        this.fgProduct=false;
        this.popProducts=[];
        this.popProduct=false;

        for (let i = 0; i <= this.cartItems.length; i++) {
            if (this.cartItems[i] != undefined) {
                if (this._isTargetedorPopFunds === 'LB2BFinishedGoods') {
                    if (this.cartItems[i].cartItem.productDetails.fields.Product_Classification__c !== null) {
                        this.fgProduct=true;
                        this.fgProducts.push(this.cartItems[i].cartItem.productDetails.sku);
                    }
                }
                else if (this._isTargetedorPopFunds === 'LB2BPointofPurchase') {
                    if (this.cartItems[i].cartItem.productDetails.fields.Product_Classification__c === null) {
                        this.popProduct=true;
                        this.popProducts.push(this.cartItems[i].cartItem.productDetails.sku);
                    }
                }

            }
        }
    }
     
    @track Internalsales;
    showHideWorkflowId(value){
        return this.Internalsales=value;
    }
    handleEvent(data) {
        this.error = true;
        this.errorMsg = data;
    }

    handleNextPage(data) {
        console.log("handle next page : ", data)
        this.pageParam = data;
        this.updateCartItems();
    }

    handlePreviousPage(data) {
        console.log("handle previous page : ", data)
        this.pageParam = data;
        this.updateCartItems();
    }

       

    /**
     * Get a list of cart items from the server via imperative apex call
     */
    updateCartItems() {
        // Call the 'getCartItems' apex method imperatively
        getCartItems({
            communityId: communityId,
            effectiveAccountId: this.resolvedEffectiveAccountId,
            activeCartOrId: this.recordId,
            productFields: 'Brand__c,LB2BPromotionDisplayName__c,product_classification__c',
            pageParam: this.pageParam,
            pageSize: this.pageSize,
            sortParam: this.sortParam

        })
            .then((result) => {
                this.cartItems = result.cartItems;

                //mapping workflow id to cartItems obj
                console.log('this.newupdatedCartItems-->', this.newupdatedCartItems)
                if(this.newupdatedCartItems){
                    this.cartItems.forEach((itemsArray)=> this.newupdatedCartItems.forEach((updatedArray)=> {
                        if(itemsArray.cartItem.cartItemId === updatedArray.Id){
                            itemsArray.cartItem.workflowId = (updatedArray.LB2BItemWorkFlowId__c) ? updatedArray.LB2BItemWorkFlowId__c : '';
                        }
                    }));
                    this.isLoading=false;
                }
             
                this._cartItemCount = Number(
                    result.cartSummary.uniqueProductCount
                );
                this._records = result.cartItems;
                this.hidePagination = this._records.length == 0 ? false : true;
                this.nextPageToken = result.nextPageToken;
                this.previousPageToken = result.previousPageToken;
                this.currencyCode = result.cartSummary.currencyIsoCode;
                this.isCartDisabled = LOCKED_CART_STATUSES.has(
                    result.cartSummary.status
                );

                for (let i = 0; i <= this.cartItems.length; i++) {
                    if (this.cartItems[i] != undefined) {
                        if (this.cartItems[i].cartItem.productDetails.purchaseQuantityRule != null) {
                            this.cartItems[i].cartItem.min = parseInt(this.cartItems[i].cartItem.productDetails.purchaseQuantityRule.minimum);
                            this.cartItems[i].cartItem.inc = parseInt(this.cartItems[i].cartItem.productDetails.purchaseQuantityRule.increment);
                            this.cartItems[i].cartItem.max = parseInt(this.cartItems[i].cartItem.productDetails.purchaseQuantityRule.maximum);
                            this.cartItems[i].cartItem.qtyRule = true;
                        }
                        else {
                            this.cartItems[i].cartItem.min = 1;
                            this.cartItems[i].cartItem.inc = 1;
                            this.cartItems[i].cartItem.max = 1000000;
                            this.cartItems[i].cartItem.qtyRule = false;
                        }
                    }
                }
            })
            .catch((error) => {
                const errorMessage = error.body.message;
                console.log("error cart", error);
                this.cartItems = undefined;
                this.isCartClosed = isCartClosed(errorMessage);
            });
    }

    /**
     * Handles a "click" event on the sort menu.
     *
     * @param {Event} event the click event
     * @private
     */
    handleChangeSortSelection(event) {
        this.sortParam = event.target.value;
        // After the sort order has changed, we get a refreshed list
        this.updateCartItems();
    }

    /**
     * Helper method to handle updates to cart contents by firing
     *  'cartchanged' - To update the cart badge
     *  'cartitemsupdated' - To notify any listeners for cart item updates (Eg. Cart Totals)
     *
     * As of the Winter 21 release, Lightning Message Service (LMS) is not available in B2B Commerce for Lightning.
     * These samples make use of the [pubsub module](https://github.com/developerforce/pubsub).
     * In the future, when LMS is supported in the B2B Commerce for Lightning, we will update these samples to make use of LMS.
     *
     * @fires CartContents#cartchanged
     * @fires CartContents#cartitemsupdated
     *
     * @private
     */
    handleCartUpdate() {
        // Update Cart Badge
        this.dispatchEvent(
            new CustomEvent(CART_CHANGED_EVT, {
                bubbles: true,
                composed: true
            })
        );
        // Notify any other listeners that the cart items have updated
        fireEvent(this.pageRef, CART_ITEMS_UPDATED_EVT);
    }

    /**
     * Handler for the 'quantitychanged' event fired from cartItems component.
     *
     * @param {Event} evt
     *  A 'quanitychanged' event fire from the Cart Items component
     *
     * @private
     */

    handleQuantityChanged(evt) {
        const { cartItemId, quantity, qtyMin, qtyInc, qtyMax } = evt.detail;
        if (quantity > qtyMax) {
            this.isError = true;
            fireEvent(this.pageRef, 'invalidQuantity', this.isError);
            let msg = this.label.LB2BQtyMsg1+' '+ qtyMin + ' - ' + qtyMax
                + this.label.LB2BQtyMsg2 +' '+qtyInc;
            this.dispatchEvent(
                new ShowToastEvent({
                    title: this.label.LB2BError,
                    message: msg,
                    variant: 'error'
                })
            )
        }
        else {
            updateCartItem({
                communityId,
                effectiveAccountId: this.effectiveAccountId,
                activeCartOrId: this.recordId,
                cartItemId,
                cartItem: { quantity }
            })
                .then((cartItem) => {
                    this.updateCartItems();
                    //this.updateCartItemInformation(cartItem);
                    this.isError = false;
                    fireEvent(this.pageRef, 'invalidQuantity', this.isError);
                })
                .catch((error) => {
                    this.isError = true;
                    fireEvent(this.pageRef, 'invalidQuantity', this.isError);

                    //let message = JSON.stringify(error.body.message);
                    let message = this.label.LB2BQtyMsg1 +' '+ qtyMin + ' - ' + qtyMax
                        + this.label.LB2BQtyMsg2 +' '+ qtyInc;

                    console.log("Message:", message);

                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: this.label.LB2BInvalidQuantity,
                            message: message,
                            variant: 'error'
                        })
                    )
                });
        }
    }

    /**
     * Handler for the 'singlecartitemdelete' event fired from cartItems component.
     *
     * @param {Event} evt
     *  A 'singlecartitemdelete' event fire from the Cart Items component
     *
     * @private
     */
    handleCartItemDelete(evt) {
        const { cartItemId } = evt.detail;
        deleteCartItem({
            communityId,
            effectiveAccountId: this.effectiveAccountId,
            activeCartOrId: this.recordId,
            cartItemId
        })
            .then(() => {
                this.removeCartItem(cartItemId);
            })
            .catch((e) => {
                // Handle cart item delete error properly
                // For this sample, we can just log the error
                console.log(e);
            });
    }

    /**
     * Handler for the 'click' event fired from 'Clear Cart' button
     * We want to delete the current cart, create a new one,
     * and navigate to the newly created cart.
     *
     * @private
     */

    handleClearCartButtonClicked() {
        // if (this.cartItem && this.cartItem.length > 0) {
        //     console.log('cart length', this.cartItem.length);
        //     this.disabled = false;
        // }
        // else {
        //     console.log('empty cart', this.cartItem.length);
        //     this.disabled = true;
        // }
        this.customFormModal = true;
    }

    customDelete(event) {
        // Step 1: Delete the current cart
        deleteCart({
            communityId,
            effectiveAccountId: this.effectiveAccountId,
            activeCartOrId: this.recordId
        })
            .then(() => {
                // Step 2: If the delete operation was successful,
                // set cartItems to undefined and update the cart header
                this.cartItems = undefined;
                this._cartItemCount = 0;
            })
            .then(() => {
                // Step 3: Create a new cart
                return createCart({
                    communityId,
                    effectiveAccountId: this.effectiveAccountId
                });
            })
            .then((result) => {
                // Step 4: If create cart was successful, navigate to the new cart
                this.navigateToCart(result.cartId);
                this.handleCartUpdate();
            })
            .catch((e) => {
                // Handle quantity any errors properly
                // For this sample, we can just log the error
                console.log(e);
            });
    }

    /**
     * Given a cart id, navigate to the record page
     *
     * @private
     * @param{string} cartId - The id of the cart we want to navigate to
     */
    navigateToCart(cartId) {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: cartId,
                objectApiName: 'WebCart',
                actionName: 'view'
            }
        });
    }

    /**
     * Given a cartItem id, remove it from the current list of cart items.
     *
     * @private
     * @param{string} cartItemId - The id of the cart we want to navigate to
     */
    removeCartItem(cartItemId) {
        this.popProducts=[];
        this.fgProducts=[];
        this.fgProduct=false;
        this.popProduct=false;

        const removedItem = (this.cartItems || []).filter(
            (item) => item.cartItem.cartItemId === cartItemId
        )[0];
        const quantityOfRemovedItem = removedItem
            ? removedItem.cartItem.quantity
            : 0;
        const updatedCartItems = (this.cartItems || []).filter(
            (item) => item.cartItem.cartItemId !== cartItemId
        );
        // Update the cartItems with the change
        this.cartItems = updatedCartItems;

        for (let i = 0; i <= this.cartItems.length; i++) {
            if (this.cartItems[i] != undefined) {
                if (this._isTargetedorPopFunds === 'LB2BFinishedGoods') {
                    if(this.cartItems[i].cartItem.productDetails.fields.Product_Classification__c !== null) {                   
                            this.fgProduct=true;
                            this.fgProducts.push(this.cartItems[i].cartItem.productDetails.sku);
                    }
                }
                else if (this._isTargetedorPopFunds === 'LB2BPointofPurchase') {  
                    if (this.cartItems[i].cartItem.productDetails.fields.Product_Classification__c === null) {
                                this.popProduct = true;
                                this.popProducts.push(this.cartItems[i].cartItem.productDetails.sku);
                        }
                }
            }
        } 
        // Update the Cart Header with the new count
        //  this._cartItemCount = Number(quantityOfRemovedItem);
        this._cartItemCount--;

        if (this._cartItemCount == 0) {
            this.customDelete();
            this.error = false;
        } else {
            // Update the cart badge and notify any other components interested in this change
            this.handleCartUpdate();
        }

        if (this.cartItems.length === 0) {
            console.log("inside if : ", this.cartItems.length);
            // this.handlePreviousPage(this.previousPageToken);
            this.isLastItemDeleted = true;
            fireEvent(this.pageRef, 'itemDeleted', this.isLastItemDeleted);
        }
    }

    /**
     * Given a cartItem id, remove it from the current list of cart items.
     *
     * @private
     * @param{CartItem} cartItem - An updated cart item
     */
    updateCartItemInformation(cartItem) {
        // Get the item to update the product quantity correctly.
        let count = 0;
        const updatedCartItems = (this.cartItems || []).map((item) => {
            // Make a copy of the cart item so that we can mutate it
            let updatedItem = { ...item };
            if (updatedItem.cartItem.cartItemId === cartItem.cartItemId) {
                updatedItem.cartItem = cartItem;
            }
            //  count += Number(updatedItem.cartItem.quantity);
            return updatedItem;
        });
        // Update the cartItems List with the change
        this.cartItems = updatedCartItems;
        // Update the Cart Header with the new count
        //  this._cartItemCount = count;
        // Update the cart badge and notify any components interested with this change
        this.handleCartUpdate();
    }

    @wire(getRecord, { recordId: USER_ID, fields: [Name] })
    user;

    get accountName() {
        return getFieldValue(this.user.data, Name);

    }
    /*Newly Added---------- */
    @wire(getRecord, { recordId: USER_ID, fields: [SAP_CustomerNumber, Brand_Name] })
    number;

    get SapCustomerNo() {

        return getFieldValue(this.number.data, SAP_CustomerNumber);
    }

    get BrandName() {
        return getFieldValue(this.number.data, Brand_Name);
    }
    /*-------------------------*/
    // @api recordId;
    // @track shipAdd;

    @wire(getRecord, { recordId: USER_ID, fields: [ShippingStreet, ShippingCity, ShippingState, ShippingCountry, ShippingPostalCode] })
    add;


    get shipStr() {
        return getFieldValue(this.add.data, ShippingStreet);

    }
    get shipcity() {
        return getFieldValue(this.add.data, ShippingCity);
    }
    get shipcon() {
        return getFieldValue(this.add.data, ShippingCountry);
    }
    get shipstate() {
        return getFieldValue(this.add.data, ShippingState);
    }
    get shipCode() {
        return getFieldValue(this.add.data, ShippingPostalCode);
    }


    navigateToQuickOrder(event) {

        // getCartTotal();
        let url = window.location.href.split("/s/");
        let newUrl = url[0] + "/s/quick-order";
        console.log("url+", url);
        // let url = window.location.href;
        // let newUrl = url.replace(/cart/, 'checkout');
        console.log("url", newUrl);
        //this.showSpinner = false;      
        this.navigateToWebPage(newUrl);

    }

    navigateToWebPage(url) {
        console.log(url, "this is our url")
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                // objectApiName: 'Order_Review__c',
                // actionName: 'view'
                url: url
            }
        });

    }


    //Boolean tracked variable to indicate if modal is open or not default value is false as modal is closed when page is loaded 
    openModal() {
        // to open modal set isModalOpen track value as true
        this.isModalOpen = true;

    }
    closeModal() {
        // to close modal set isModalOpen track value as false
        this.isModalOpen = false;
    }


    /*Handle Radio button Change */

    handleRadioChange(event) {
        let selectedOption = event.target.value;
        console.log('selectedOption ', selectedOption);

        if (selectedOption == 'createList') {
            this.createListValue = true;
        } else {
            this.createListValue = false;
        }


        if (selectedOption == 'addToList') {
            this.addToListValue = true;
        } else {
            this.addToListValue = false;
        }
    }



    /**
    * Handles a user request to add the product to a newly created wishlist.
    * On success, a success toast is shown to let the user know the product was added to a new list
    * If there is an error, an error toast is shown with a message explaining that the product could not be added to a new list
    *
    * @private
    */


    handleAllAddToListButton() {
        // if (this.cartItem && this.cartItem.length === 0) {
        //     console.log('cart length', this.cartItem.length);
        //     this.disabled = true;
        // }
        // else {
        //     console.log('empty cart', this.cartItem.length);
        //     this.disabled = true;
        // }
        this.isModalOpen = false;

        if (this.createListValue == true) {

            this.listname = this.template.querySelector(`[data-id = "newlist"]`).value;

            createWishlist({
                communityId,
                effectiveAccountId: this.effectiveAccountId,
                listname: this.listname
            })
                .then((result) => {
                    this.wishlist = result.summary;
                    this.newWishlistId = result.summary.id;

                    copyCartToWishlist({
                        communityId,
                        effectiveAccountId: this.effectiveAccountId,
                        activeCartOrId: this.recordId,
                        wishlistId: this.newWishlistId
                    })
                        .then((result) => {
                            console.log("Success:", result);

                            this.dispatchEvent(
                                new ShowToastEvent({
                                    title: this.label.LB2BSuccess,
                                    message: this.label.LB2BProductsWishlistMsg,
                                    variant: 'success',
                                    mode: 'dismissable'
                                })
                            );
                        })
                        .catch((error) => {
                            let message = error.body.message;
                            console.log("Error Msg:", message);

                            this.dispatchEvent(
                                new ShowToastEvent({
                                    title: this.label.LB2BError,
                                    message: message,
                                    variant: 'error',
                                    mode: 'dismissable'
                                })
                            );
                        });

                })
                .catch((error) => {
                    let message = error.body.message;
                    console.log("Error Msg:", message);

                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: this.label.LB2BError,
                            message: message,
                            variant: 'error',
                            mode: 'dismissable'
                        })
                    );
                });
        }

        if (this.addToListValue == true) {
            let lName = this.template.querySelector(`[data-id = "existinglist"]`).value;

            let id;
            for (let i = 0; i < this.existingListsLength; i++) {
                if (this.data.summaries[i].name == lName) {
                    id = this.data.summaries[i].id;
                }
            }
            this.wishlistId = id;
            console.log("WishlistId: ", this.wishlistId);

            copyCartToWishlist({
                communityId,
                effectiveAccountId: this.effectiveAccountId,
                activeCartOrId: this.recordId,
                wishlistId: this.wishlistId
            })
                .then((result) => {
                    console.log("Success:", result);

                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: this.label.LB2BSuccess,
                            message: this.label.LB2BProductsWishlistMsg,
                            variant: 'success',
                            mode: 'dismissable'
                        })
                    );
                })
                .catch((error) => {
                    let message = error.body.message;
                    console.log("Error Msg:", message);

                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: this.label.LB2BError,
                            message: message,
                            variant: 'error',
                            mode: 'dismissable'
                        })
                    );
                });

        }

    }

    getLists() {
        getWishlistSummaries({
            communityId,
            effectiveAccountId: this.effectiveAccountId
        })
            .then((result) => {
                this.data = JSON.parse(JSON.stringify(result));

                let listOption = [];

                this.existingListsLength = result.summaries.length;

                for (let i = 0; i < this.existingListsLength; i++) {
                    this.existingListName = result.summaries[i].name;

                    listOption.push({
                        label: this.existingListName.replace('&amp;', '&')
                            .replace('&lt;/p&gt;', '')
                            .replace('&amp;amp;', '&')
                            .replace('&amp;#39;', "'"),
                        value: this.existingListName
                    });

                }
                this.existingLists = listOption;
                //console.log("ExlistOptions:" ,JSON.parse(JSON.stringify(this.existingLists)));

                if (this.existingLists != 0) {
                    this.showExistingLists = true;
                }

            });
    }

    /*Handle Existing Lists Dropdown*/
    handleExistingLists(event) {
        this.value = event.detail.value;
    }

    get options() {
        return this.existingLists;
    }

    handelOrderType() {
        this.callgetCartItemDetails();
        this.isLoading = true;
     }

     // Getter
    get hasInternalAccess(){
        return hasPermission;   
    }
    
    // Getter
    get isExportAffiliateUser() {
        return hasExportAffiliateUser;
    }

    // code for Promotions via PCR Codes
    handleUpatePCR(event){
        let key = event.currentTarget.dataset.id;
        this.pcrcodes[key] = event.target.value;
        console.log('pcrcodes >>>>>>',this.pcrcodes);
        this.pcrNotesValidation();
        this.updateOrderTypeRecords();
    }

    pcrNotesValidation(){
        for(let i = 0; i< this.pcrcodes.length; i++){
            if(this.pcrcodes[i] != '') {
                this.isPcrNotes = true ;
                break;
            } else {
                this.isPcrNotes = false;  
            }   
            
        }
        this.isEmpty = (currentValue) => currentValue === '';
        console.log('every>>>',this.pcrcodes.every(this.isEmpty)) ;
        if(this.pcrcodes.every(this.isEmpty)){
            this.pcrNotes = ''; 
            this.updateOrderTypeRecords();
        }

        this.pcrObj.pcrNotes = this.pcrNotes;
        this.pcrObj.isPcrcodeEmpty = this.pcrcodes.every(this.isEmpty);
        fireEvent(this.pageRef, 'valdiatedPCR', this.pcrObj);
    }

    handleUpatePCRNotes(event){
        this.pcrNotes = event.target.value;
        console.log('pcrnotes',this.pcrNotes);
        this.pcrObj.pcrNotes = this.pcrNotes;
        this.pcrObj.isPcrcodeEmpty = this.pcrcodes.every(this.isEmpty);
        fireEvent(this.pageRef, 'valdiatedPCR', this.pcrObj);
        this.updateOrderTypeRecords();
    }

    updateOrderTypeRecords() {
        let fields = {};
        fields[ID_FIELD.fieldApiName] = this.recordId;
        fields[ORDERTYPEPICKLIST.fieldApiName] = this.ordertype;
        fields[PCRCode_1.fieldApiName] = this.pcrcodes[0];
        fields[PCRCode_2.fieldApiName] = this.pcrcodes[1];
        fields[PCRCode_3.fieldApiName] = this.pcrcodes[2];
        fields[PCRCode_4.fieldApiName] = this.pcrcodes[3];
        fields[PCRCode_5.fieldApiName] = this.pcrcodes[4];
        fields[PCR_Notes.fieldApiName] = this.pcrNotes;

        const recordInput = {
            fields: fields
        };
       
        updateRecord(recordInput)
            .then((result) => {
                console.log('resulttttt', result);
            })
            .catch((error) => {
                console.log('error while updating', error);
            });
    }
}