/**
 * @description       :
 * @author            : Stefanie Elling
 * @group             :
 * @last modified on  : 05-23-2022
 * @last modified by  : Stefanie Elling
 **/
import { LightningElement, api, track, wire } from 'lwc';
import LB2BListViewPLP from '@salesforce/label/c.LB2BListViewPLP';
import LB2BGridViewPLP from '@salesforce/label/c.LB2BGridViewPLP';
import LB2BSortBy from '@salesforce/label/c.LB2BSortBy';
import communityId from '@salesforce/community/Id';
import { CurrentPageReference } from 'lightning/navigation';
import { fireEvent } from 'c/lb2bPubSub';
import getSortResults from '@salesforce/apex/LB2BSearchPLPController.getSortResults';

const LOCAL_STORAGE_VARIABLE = 'sbd365-displayMode';
const DISPLAY_MODE = {
    GRID: 'grid',
    LIST: 'list'
};

/**
 * An organized display of product cards.
 *
 * @fires SearchLayout#calltoaction
 * @fires SearchLayout#showdetail
 */
export default class lb2bSearchLayout extends LightningElement {
    displayMode = DISPLAY_MODE.LIST;

    @api
    effectiveAccountId;

    @api
    resultsCount;

    @api
    sortValues = [];

    labels = {
        LB2BListViewPLP,
        LB2BGridViewPLP,
        LB2BSortBy
    };

    /**
 * An object with the current PageReference.
 * This is needed for the pubsub library.
 *
 * @type {PageReference}
 */

    @wire(CurrentPageReference)
    pageRef;
 
    @track selectedSortValue;
    @track sortRuleId;
    @track isLoading = false;
    @api
    defaultSortValue;

    get isGridView() {
        return this.displayMode === DISPLAY_MODE.GRID;
    }

    get isListView() {
        return this.displayMode === DISPLAY_MODE.LIST;
    }

    connectedCallback() {
        this.isLoading = false;
        getSortResults({
            communityId: communityId
        }).then((result) => {
            this.selectedSortValue = result.sortRules[0].label;
            let options = [];
            for (let i = 0; i < result.sortRules.length; i++) {
                options.push({
                        label: result.sortRules[i].label,
                        value: result.sortRules[i].sortRuleId
                    });
            }
            this.sortValues = options;

           // fireEvent(this.pageRef, 'isSortRuleId', this.sortRuleId);       
            this.isLoading = true;
        })
            .catch((error) => {
                console.error('An error occurred getting breadcrumbs', error);
            });

        if (this.mobileView()) {
            return;
        }

        const savedDisplayMode = localStorage.getItem(LOCAL_STORAGE_VARIABLE);
        if (savedDisplayMode) {
            this.displayMode = savedDisplayMode;
        } else {
            this.displayMode = DISPLAY_MODE.GRID;
        }
    }

    get sortValue() {
        return this.selectedSortValue || this.defaultSortValue;
    }
    
    /**
     * An event fired when the user clicked on the action button. Here in this
     *  this is an add to cart button.
     *
     * Properties:
     *   - Bubbles: true
     *   - Composed: true
     *   - Cancelable: false
     *
     * @event SearchLayout#calltoaction
     * @type {CustomEvent}
     *
     * @property {String} detail.productId
     *   The unique identifier of the product.
     *
     * @export
     */

    /**
     * An event fired when the user indicates a desire to view the details of a product.
     *
     * Properties:
     *   - Bubbles: true
     *   - Composed: true
     *   - Cancelable: false
     *
     * @event SearchLayout#showdetail
     * @type {CustomEvent}
     *
     * @property {String} detail.productId
     *   The unique identifier of the product.
     *
     * @export
     */

    /**
     * A result set to be displayed in a layout.
     * @typedef {object} Product
     *
     * @property {string} id
     *  The id of the product
     *
     * @property {string} name
     *  Product name
     *
     * @property {Image} image
     *  Product Image Representation
     *
     * @property {object.<string, object>} fields
     *  Map containing field name as the key and it's field value inside an object.
     *
     * @property {Prices} prices
     *  Negotiated and listed price info
     */

    /**
     * A product image.
     * @typedef {object} Image
     *
     * @property {string} url
     *  The URL of an image.
     *
     * @property {string} title
     *  The title of the image.
     *
     * @property {string} alternativeText
     *  The alternative display text of the image.
     */

    /**
     * Prices associated to a product.
     *
     * @typedef {Object} Pricing
     *
     * @property {string} listingPrice
     *  Original price for a product.
     *
     * @property {string} negotiatedPrice
     *  Final price for a product after all discounts and/or entitlements are applied
     *  Format is a raw string without currency symbol
     *
     * @property {string} currencyIsoCode
     *  The ISO 4217 currency code for the product card prices listed
     */

    /**
     * Gets or sets the display data for layout.
     *
     * @type {Product[]}
     */
    @api
    displayData;

    /**
     * Gets the container class which decide the inner element styles.
     *
     * @type {string}
     * @readonly
     * @private
     */
    get layoutContainerClass() {
        return this.displayMode === DISPLAY_MODE.GRID ? 'layout-grid' : 'layout-list';
    }

    get listVariant() {
        return this.isListView ? 'brand' : 'neutral';
    }

    get gridVariant() {
        return this.isGridView ? 'brand' : 'neutral';
    }

    handleListViewClick() {
        this.displayMode = DISPLAY_MODE.LIST;
        localStorage.setItem(LOCAL_STORAGE_VARIABLE, DISPLAY_MODE.LIST);
    }

    handleGridViewClick() {
        this.displayMode = DISPLAY_MODE.GRID;
        localStorage.setItem(LOCAL_STORAGE_VARIABLE, DISPLAY_MODE.GRID);
    }

    handleSortRuleClick(event) {
        this.selectedSortValue = event.target.label;
        this.sortRuleId = event.target.value;
        //fire event to search Result lwc 
      //  fireEvent(this.pageRef, 'isSortRuleId', event.target.value);
        this.dispatchEvent(
            new CustomEvent('sortrulechange', {
                detail: this.sortRuleId
            })
        );
    }

    mobileView() {
        if (window.innerWidth < 481) {
            this.displayMode = DISPLAY_MODE.GRID;
            return true;
        }

        return false;
    }
}