import { LightningElement, api, wire } from 'lwc';
import communityId from '@salesforce/community/Id';
import getProduct from '@salesforce/apex/LB2BGetUserInformation.getProduct';
import LB2BProductsLoading from '@salesforce/label/c.LB2BProductsLoading';
import { HtmlHelper } from 'c/lb2bUtil';

export default class Lb2bProductDetails extends LightningElement {
    /**
     * Gets the effective account - if any - of the user viewing the product.
     *
     * @type {string}
     */
    @api
    get effectiveAccountId() {
        return this._effectiveAccountId;
    }

    /**
     * Sets the effective account - if any - of the user viewing the product
     * and fetches updated cart information
     */
    set effectiveAccountId(newId) {
        this._effectiveAccountId = newId;
    }

    /**
     * Gets or sets the unique identifier of a product.
     *
     * @type {string}
     */
    @api
    recordId;

    /**
     * Gets or sets the custom fields to display on the product
     * in a comma-separated list of field names
     *
     * @type {string}
     */
    @api
    customDisplayFields;

    @api currencycode;
    @api productname;
    @api productsku;
    @api brand;
    @api description;
    @api upc;
    @api stock;

    label = {
        LB2BProductsLoading
    };

    /**
     * The full product information retrieved.
     *
     * @type {ConnectApi.ProductDetail}
     * @private
     */
    @wire(getProduct, {
        communityId: communityId,
        productId: '$recordId',
        effectiveAccountId: '$resolvedEffectiveAccountId'
    })
    product;

    /**
     * Gets the normalized effective account of the user.
     *
     * @type {string}
     * @readonly
     * @private
     */
    get resolvedEffectiveAccountId() {
        const effectiveAccountId = this.effectiveAccountId || '';
        let resolved = null;

        if (effectiveAccountId.length > 0 && effectiveAccountId !== '000000000000000') {
            resolved = effectiveAccountId;
        }
        return resolved;
    }

    /**
     * Gets whether product information has been retrieved for display.
     *
     * @type {Boolean}
     * @readonly
     * @private
     */
    get hasProduct() {
        return this.product.data !== undefined;
    }
    @api stockcolor;
    @api ecommercecopy;
    /**
     * Gets the normalized, displayable product information for use by the display components.
     *
     * @readonly
     */
    get displayableProduct() {
        //console.log("Product Fields:" ,this.product);
        let prodInv =
            this.product.data.fields.LB2BProductQuantityinInventory__c == null
                ? 0
                : this.product.data.fields.LB2BProductQuantityinInventory__c;
        if (prodInv > 100) {
            this.stockcolor = 'greenColor';
        } else if (prodInv > 0) {
            this.stockcolor = 'yellowColor';
        } else {
            this.stockcolor = 'redColor';
        }
        if (this.product.data.fields.ecommercecopy__c == null) {
            this.ecommercecopy = '';
        } else {
            this.ecommercecopy = this.product.data.fields.ecommercecopy__c;
        }

        return {
            currencycode : this.product.data.fields.CurrencyIsoCode,
            productname : this.product.data.fields.Name,
            productsku : this.product.data.fields.StockKeepingUnit,
            brand: this.product.data.fields.Brand__c,
            description: this.ecommercecopy,
            upc: this.product.data.fields.productupc__c,
            stock: this.product.data.fields.LB2BStockAvailability__c,
            stockcolor: this.stockcolor,
            features: this.product.data.fields.featurebenefitvalue__c ? HtmlHelper.parseHtml(this.product.data.fields.featurebenefitvalue__c) : '',

            customFields: Object.entries(this.product.data.fields || Object.create(null))
                .filter(([key]) => (this.customDisplayFields || '').includes(key))
                .map(([key, value]) => ({ name: key, value }))
        };
    }
}