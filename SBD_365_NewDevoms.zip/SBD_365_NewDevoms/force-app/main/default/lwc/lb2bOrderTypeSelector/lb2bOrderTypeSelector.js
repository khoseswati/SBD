import { LightningElement, api, wire, track } from 'lwc';
import ORDERTYPEPICKLIST from '@salesforce/schema/WebCart.LB2BOrderType__c';
import COSTCENTER from '@salesforce/schema/WebCart.LB2BCostCenter__c';
import WORKFLOWID from '@salesforce/schema/WebCart.LB2BWorkFlowId__c';
import Reasoncode from '@salesforce/schema/WebCart.LB2BReasoncode__c';
import ID_FIELD from '@salesforce/schema/WebCart.Id';
import getOrderDetails from "@salesforce/apex/LB2BOrderTypeSelectorController.getOrderDetails";
import updateGetCartItemDetails from '@salesforce/apex/LB2BOrderTypeSelectorController.updateGetCartItemDetails';
import LB2BCostCenter from '@salesforce/label/c.LB2BCostCenter';
import LB2BSelectOrderType from '@salesforce/label/c.LB2BSelectOrderType';
import LB2BWorkFlowId from '@salesforce/label/c.LB2BWorkFlowId';
import ReasonCode from '@salesforce/label/c.LB2BReasonCode';
import SelectReasonCode from '@salesforce/label/c.LB2BSelectReasonCode';
import hasExportAffiliateUser from '@salesforce/customPermission/Export_Affiliate_User';
import SalesRepCA from '@salesforce/customPermission/Sales_Rep_CA';
import LOCALE from '@salesforce/i18n/locale';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import { CurrentPageReference } from 'lightning/navigation';
import { updateRecord } from 'lightning/uiRecordApi';
import { fireEvent } from 'c/lb2bPubSub';

export default class lb2bOrderTypeSelector extends LightningElement {


    @api getOrderSummary;
    @api isInternalSales;
    @api checkSapFlags;
    @api cartId;
    @api costcenter;
    @api workflowId;
    @api ordertypes;
    @api order;
    @track picklistValues;
    @track error;
    @track ordertype;
    @track workflow;
    @track selectedOption;
    @track isLoading = false;
    removeValue = 'LB2BExportAffiliate';
    @track isNotFinishedGoods = false;
    reasonCodeValue;
    reasonCodeOptions;
    @track reasonCodeValues = [];

    label = {
        LB2BCostCenter,
        LB2BSelectOrderType,
        LB2BWorkFlowId,
        ReasonCode,
        SelectReasonCode
    };
    /**
     * An object with the current PageReference.
     * This is needed for the pubsub library.
     *
     * @type {PageReference}
     */

    @wire(CurrentPageReference)
    pageRef;

    //@track value = 'End User Shows, events';
   

    get reasonCodeOptions() {
        let options = [];
        if (this.ordertype === 'LB2BOnLoan') {
            options.push({ label: 'End User Shows, events', value: 'End User Shows, events' });
        } else if (this.ordertype === 'LB2BTargetedFunds' && SalesRepCA) {
            options.push({ label: 'Advertising, signage', value: 'Advertising, signage' });
            options.push({ label: 'End User Shows, events', value: 'End User Shows, events' });
            options.push({ label: 'Dist. Incentives (Spiff)', value: 'Dist. Incentives (Spiff)' });
            options.push({ label: 'Negotiated Contract', value: 'Negotiated Contract' });
        }
        options.push({ label: 'Net Down Selling Price', value: 'Net Down Selling Price' });
        options.push({ label: 'Trade Shows', value: 'Trade Shows' });
        options.push({ label: 'Cust. Concessions/Goodwill', value: 'Cust. Concessions/Goodwill' });
        options.push({ label: 'All Other', value: 'All Other' });

        return options;
    }

    get isReasonCodecOptions() {
        if (this.ordertype === 'LB2BOnLoan' || (this.ordertype === 'LB2BTargetedFunds' && SalesRepCA)) {
            return true;
        }
        else {
            return false;
        }
    }

    connectedCallback() {
        this.callGetOrderDetails();
    }

    callGetOrderDetails() {
        getOrderDetails({
            webcartId: this.cartId
        })
            .then((result) => {
                this.getOrderSummary = result[0];
                this.costcenter = this.getOrderSummary.LB2BCostCenter__c;
                this.ordertype = this.getOrderSummary.LB2BOrderType__c;
                this.workflow = this.getOrderSummary.LB2BWorkFlowId__c;
                this.reasonCodeValue = this.getOrderSummary.LB2BReasoncode__c;
                //fire event for cart ordersummary component
                fireEvent(this.pageRef, 'CostcenterValue', this.costcenter);
                fireEvent(this.pageRef, 'isWorkFlowId', this.workflow);
                fireEvent(this.pageRef, 'reasonCodeValue', this.reasonCodeValue);
                if (this.ordertype === 'LB2BTargetedFunds' || this.ordertype === 'LB2BPointofPurchase' || this.ordertype === 'LB2BFinishedGoods' ||  'LB2BOnLoan' || 'LB2BFreeGoods') {
                    //fire event for cart ordersummary component
                    fireEvent(this.pageRef, 'isTargetedorPopFunds', this.ordertype);                  
                    //fire event for accountSelectorV2 component
                    fireEvent(this.pageRef, 'isPop', this.ordertype);
                }
                
                if (this.ordertype === 'LB2BOnLoan') {
                    this.reasonCodeValues = this.reasonCodeOptions;
                    this.reasonCodeValues = this.reasonCodeValues.filter(values => values.value !== 'C1')
                        .filter(values => values.value !== 'C3')
                        .filter(values => values.value !== 'C4');
                } else if (this.ordertype === 'LB2BTargetedFunds'){
                    this.reasonCodeValues = this.reasonCodeOptions;
                }

                this.isNotFinishedGoods = (this.ordertype === 'LB2BTargetedFunds' || this.ordertype === 'LB2BPointofPurchase' || this.ordertype === 'LB2BOnLoan' || this.ordertype === 'LB2BFreeGoods' ) ? true : false ;

            })
    }

    @wire(getPicklistValues, {
        recordTypeId: '012000000000000AAA',
        fieldApiName: ORDERTYPEPICKLIST
    })
    wiredPicklistValues({
        data,
        error
    }) {
        // reset values to handle eg data provisioned then error provisioned
        if (data) {
            console.log('data >>> ',data);
            this.picklistValues = data.values;

            if (SalesRepCA) {
                this.picklistValues = this.picklistValues.filter(values => values.value !== this.removeValue)
                    .filter(values => values.value !== 'LB2BDomesticAffiliates');
            }
            else {
                this.picklistValues = this.picklistValues.filter(values => values.value !== this.removeValue)
                    .filter(values => values.value !== 'LB2BOnLoan')
                    .filter(values => values.value !== 'LB2BFreeGoods')
                    .filter(values => values.value !== 'LB2BDomesticAffiliates');
            }
            this.error = undefined;
        } else if (error) {
            console.log(error);
            this.error = error;
            this.picklistValues = data.values;
        }
    }

    @wire(getPicklistValues, {
        recordTypeId: '012000000000000AAA',
        fieldApiName: Reasoncode
    })
    wiredReasoncodeValues({
        data,
        error
    }) {
        // reset values to handle eg data provisioned then error provisioned
        if (data) {
            
            this.reasonCodeOptions = data.values;
            this.error = undefined;
        } else if (error) {
            console.log(error);
            this.error = error;
            // this.reasonCodeValues = data.values;
        }
    }


    //custom event to cart content component
    callCustomEvent() {
        this.dispatchEvent(
            new CustomEvent('ordertype', {
                bubbles: true,
                composed: true
            })
        );
    }

    handleOrderTypeChange(event) {
        this.ordertype = event.detail.value;
        this.costcenter = '';
        this.workflow = '';
        this.reasonCodeValue = '';
        this.updateOrderTypeRecords();
        this.callUpdateGetCartItemDetails();
        if (this.ordertype === 'LB2BTargetedFunds' || this.ordertype === 'LB2BPointofPurchase' || this.ordertype === 'LB2BFinishedGoods' ||  'LB2BOnLoan' || 'LB2BFreeGoods') {
            //fire event for cart ordersummary component
            fireEvent(this.pageRef, 'isTargetedorPopFunds', this.ordertype);
            //fire event for accountSelectorV2 component
            fireEvent(this.pageRef, 'isPop', this.ordertype);
        }
        if (this.ordertype === 'LB2BOnLoan') {
            this.reasonCodeValues = this.reasonCodeOptions;
            this.reasonCodeValues = this.reasonCodeValues.filter(values => values.value !== 'C1')
                .filter(values => values.value !== 'C3')
                .filter(values => values.value !== 'C4');
        } else if (this.ordertype === 'LB2BTargetedFunds'){
            this.reasonCodeValues = this.reasonCodeOptions;
        }

        this.isNotFinishedGoods = (this.ordertype === 'LB2BTargetedFunds' || this.ordertype === 'LB2BPointofPurchase' || this.ordertype === 'LB2BOnLoan' || 'LB2BFreeGoods') ? true : false ;
    }

    handleCostCenterChange(event) {
        this.costcenter = event.target.value;
        //fire event for cart ordersummary component
        fireEvent(this.pageRef, 'CostcenterValue', this.costcenter);
        this.updateOrderTypeRecords();
    }
    handleReasonCodeChange(event){
        this.reasonCodeValue = event.target.value;
        console.log('reasonCodeValue >>> ',this.reasonCodeValue);
        fireEvent(this.pageRef, 'reasonCodeValue', this.reasonCodeValue);
        this.updateOrderTypeRecords();
    }

    updateOrderTypeRecords() {
        let fields = {};
        fields[ID_FIELD.fieldApiName] = this.cartId;
        fields[COSTCENTER.fieldApiName] = this.costcenter;
        fields[WORKFLOWID.fieldApiName] = this.workflow;
        fields[ORDERTYPEPICKLIST.fieldApiName] = this.ordertype;
        fields[Reasoncode.fieldApiName] = this.reasonCodeValue;
        const recordInput = {
            fields: fields
        };
        console.log('recordInput', recordInput);
        updateRecord(recordInput)
            .then((result) => {
                console.log('resulttttt', result);
            })
            .catch((error) => {
                console.log('error', error);
            });
    }


    get isSelectorRequired() {
        if (this.ordertype == 'LB2BTargetedFunds') {
            if(SalesRepCA){
                return false;
            }
            return true;
        } else {
            return false;
        }
    }

    handleWorkFlowIdChange(event) {
        this.isLoading = true;
       this.workflow = event.target.value;
        //fire event to checkout button to validate workflow id not undefined
        fireEvent(this.pageRef, 'isWorkFlowId', this.workflow);
        this.updateOrderTypeRecords();
        this.callUpdateGetCartItemDetails();
    }

        callUpdateGetCartItemDetails(){

                updateGetCartItemDetails({
                    webcartId: this.cartId,
                    workflowiId: this.workflow
                })
                    .then((result) => {
                        this.isLoading = false;
                        this.callCustomEvent();                       
                    })
                    .catch((error) => {
                        console.log("error cartitems", error);
                    });
        }
    
    // Getter
    get isExportAffiliateUser() {
        return hasExportAffiliateUser;
    }

}