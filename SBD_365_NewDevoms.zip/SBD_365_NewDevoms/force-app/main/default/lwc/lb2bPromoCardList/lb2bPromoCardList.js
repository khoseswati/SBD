/**
 * @description       :
 * @author            : Stefanie Elling
 * @group             :
 * @last modified on  : 10-11-2022
 * @last modified by  : Stefanie Elling
 **/
import { LightningElement, api } from 'lwc';

export default class Lb2bPromoCardList extends LightningElement {
    @api
    displayData;

    //Landscape Image
    get imageAttribute() {
        return this.displayData.imageAttribute;
    }
}