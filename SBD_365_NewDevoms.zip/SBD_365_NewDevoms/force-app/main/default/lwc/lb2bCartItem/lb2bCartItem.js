/**
 * lb2bCartItem is a child component of LB2B_CART_cartContent.
 *
 * This component will display the number of items being added to cart.
 */

import { LightningElement, api, track, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { resolve } from 'c/lb2bCmsResourceResolver';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import LB2BClose from '@salesforce/label/c.LB2BClose';
import LB2BCancel from '@salesforce/label/c.LB2BCancel';
import LB2BCartPriceCalculated from '@salesforce/label/c.LB2BCartPriceCalculated';
import LB2BQty from '@salesforce/label/c.LB2BQty';
import LB2BDelete from '@salesforce/label/c.LB2BDelete';
import LB2BRemove_Product from '@salesforce/label/c.LB2BRemove_Product';
import LB2BUnitPrice from '@salesforce/label/c.LB2BUnitPrice';
import LB2BMinIncrement from '@salesforce/label/c.LB2BMinIncrement';
import LB2BMinimum from '@salesforce/label/c.LB2BMinimum';
import LB2BIncrement from '@salesforce/label/c.LB2BIncrement';
import LB2BErrorDetected from '@salesforce/label/c.LB2BErrorDetected';
import ID_FIELD from '@salesforce/schema/CartItem.Id';
import hasPermission from '@salesforce/customPermission/Internal_Sales_Rep';
import SalesRepCA from '@salesforce/customPermission/Sales_Rep_CA';
import ITEMWORKFLOW_ID from '@salesforce/schema/CartItem.LB2BItemWorkFlowId__c';
import { CurrentPageReference } from 'lightning/navigation';
import { HtmlHelper } from 'c/lb2bUtil';
import { updateRecord } from 'lightning/uiRecordApi';
import { registerListener } from 'c/lb2bPubSub';
import { removeProductEvent } from 'c/lb2bDataLayer';
import {addtocartEvent} from 'c/lb2bDataLayer';
import LOCALE from '@salesforce/i18n/locale';
import { fireEvent } from 'c/lb2bPubSub';

// import SAP_CustomerNumber from '@salesforce/schema/User.Account.SAP_Customer_Number__c';
// import { getRecord, getFieldValue } from "lightning/uiRecordApi";
// import Product_ID from "@salesforce/schema/Product2.Id";

//import getSingleBrand from '@salesforce/apex/LB2BCartController.getSingleBrand';
const QUANTITY_CHANGED_EVT = 'quantitychanged';
const SINGLE_CART_ITEM_DELETE = 'singlecartitemdelete';

/**
 * A non-exposed component to display cart items.
 *
 * @fires Items#quantitychanged
 * @fires Items#singlecartitemdelete
 */

export default class lb2bCartItem extends NavigationMixin(LightningElement) {
    @api getIdFromParent;
    @api getAccountId;
    @api deleteCartItemId;
    @track customFormModal = false;
    @track quantity;
    @api minimum;
    @api increment;
    @api maximum;
    @api cartId;
    _isTargetedorPopFunds;
    isFgTargetedFunds = true;

    @api label = {
        LB2BClose,
        LB2BCancel,
        LB2BQty,
        LB2BDelete,
        LB2BRemove_Product,
        LB2BUnitPrice,
        LB2BMinIncrement,
        LB2BMinimum,
        LB2BIncrement,
        LB2BErrorDetected,
        LB2BCartPriceCalculated
    };
    /**
     * An event fired when the quantity of an item has been changed.
     *
     * Properties:
     *   - Bubbles: true
     *   - Cancelable: false
     *   - Composed: true
     *
     * @event Items#quantitychanged
     * @type {CustomEvent}
     *
     * @property {string} detail.itemId
     *   The unique identifier of an item.
     *
     * @property {number} detail.quantity
     *   The new quantity of the item.
     *
     * @export
     */

    /**
     * An event fired when the user triggers the removal of an item from the cart.
     *
     * Properties:
     *   - Bubbles: true
     *   - Cancelable: false
     *   - Composed: true
     *
     * @event Items#singlecartitemdelete
     * @type {CustomEvent}
     *
     * @property {string} detail.cartItemId
     *   The unique identifier of the item to remove from the cart.
     *
     * @export
     */

    /**
     * A cart line item.
     *
     * @typedef {Object} CartItem
     *
     * @property {ProductDetails} productDetails
     *   Representation of the product details.
     *
     * @property {string} originalPrice
     *   The original price of a cart item.
     *
     * @property {number} quantity
     *   The quantity of the cart item.
     *
     * @property {string} totalPrice
     *   The total sales price of a cart item.
     *
     * @property {string} totalListPrice
     *   The total original (list) price of a cart item.
     *
     * @property {string} unitAdjustedPrice
     *   The cart item price per unit based on tiered adjustments.
     *
     * @property {string} ITEMWORKFLOW_ID
     */

    /**
     * Details for a product containing product information
     *
     * @typedef {Object} ProductDetails
     *
     * @property {string} productId
     *   The unique identifier of the item.
     *
     * @property {string} sku
     *  Product SKU number.
     *
     * @property {string} name
     *   The name of the item.
     *
     * @property {ThumbnailImage} thumbnailImage
     *   The image of the cart line item
     *
     */

    /**
     * Image information for a product.
     *
     * @typedef {Object} ThumbnailImage
     *
     * @property {string} alternateText
     *  Alternate text for an image.
     *
     * @property {string} title
     *   The title of the image.
     *
     * @property {string} url
     *   The url of the image.
     */

    /**
     * The ISO 4217 currency code for the cart page
     *
     * @type {string}
     */
    @api
    currencyCode;

    /**
     * Whether or not the cart is in a locked state
     *
     * @type {Boolean}
     */
    @api
    isCartDisabled = false;

    /**
     * A list of CartItems
     *
     * @type {CartItem[]}
     */

    customHideModalPopup() {
        this.customFormModal = false;
    }

    @wire(CurrentPageReference)
    pageRef;

    @api
    get cartItems() {
        return this._providedItems;
    }

    set cartItems(items) {
        this._providedItems = items;
        const generatedUrls = [];
        this._items = (items || []).map((item) => {
            // Create a copy of the item that we can safely mutate.
            const newItem = { ...item };

            //Gets Purchase Quantity Rule properties
            if (item.cartItem.productDetails.purchaseQuantityRule != null) {
                newItem.qtyMin =
                    this.label.LB2BMinimum +
                    ' ' +
                    parseInt(item.cartItem.productDetails.purchaseQuantityRule.minimum) +
                    ', ' +
                    this.label.LB2BIncrement +
                    ' ' +
                    parseInt(item.cartItem.productDetails.purchaseQuantityRule.increment);
            } else {
                // newItem.qtyMin = "Minimum is 1, Increments of 1";
                newItem.qtyMin = this.label.LB2BMinIncrement;
            }

            // Set default value for productUrl
            newItem.productUrl = '';
            // Get URL of the product image.
            newItem.productImageUrl =
                item.cartItem.productDetails.thumbnailImage != null
                    ? resolve(item.cartItem.productDetails.thumbnailImage.url)
                    : '';

            // Set the alternative text of the image(if provided).
            // If not, set the null all text (alt='') for images.
            newItem.productImageAlternativeText =
                item.cartItem.productDetails.thumbnailImage != null
                    ? item.cartItem.productDetails.thumbnailImage.alternateText
                    : '';

            // Get URL for the product, which is asynchronous and can only happen after the component is connected to the DOM (NavigationMixin dependency).
            const urlGenerated = this._canResolveUrls
                .then(() =>
                    this[NavigationMixin.GenerateUrl]({
                        type: 'standard__recordPage',
                        attributes: {
                            recordId: newItem.cartItem.productId,
                            objectApiName: 'Product2',
                            actionName: 'view'
                        }
                    })
                )
                .then((url) => {
                    newItem.productUrl = url;
                });
            generatedUrls.push(urlGenerated);
            // Clean up name and set a new field on newItem so we don't run into issues modifying readonly objects
            newItem.brand = HtmlHelper.parseHtml(newItem.cartItem.productDetails.fields.Brand__c);
            newItem.name = HtmlHelper.parseHtml(newItem.cartItem.productDetails.name);

            return newItem;
        });

        // When we've generated all our navigation item URLs, update the list once more.
        Promise.all(generatedUrls).then(() => {
            this._items = Array.from(this._items);
        });
    }

    /**
     * A normalized collection of items suitable for display.
     *
     * @private
     */
    _items = [];

    /**
     * A list of provided cart items
     *
     * @private
     */
    _providedItems;

    /**
     * A Promise-resolver to invoke when the component is a part of the DOM.
     *
     * @type {Function}
     * @private
     */
    _connectedResolver;

    /**
     * A Promise that is resolved when the component is connected to the DOM.
     *
     * @type {Promise}
     * @private
     */
    _canResolveUrls = new Promise((resolved) => {
        this._connectedResolver = resolved;
    });
    currentPageReference = null;

    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        if (currentPageReference) {
            console.log('bb12', currentPageReference.state);
            //  console.log("bbbb",currentPageReference.state.defaultFieldValues)
        }
    }

    /**
     * This lifecycle hook fires when this component is inserted into the DOM.
     */
    connectedCallback() {
        // Once connected, resolve the associated Promise.
        this._connectedResolver();
        console.log('ID from parent:', this.getIdFromParent);
        registerListener('isTargetedorPopFunds', this.isTargetedorPopFunds, this);
        this.PushToDataLayer();
    }

    /**
     * This lifecycle hook fires when this component is removed from the DOM.
     */
    disconnectedCallback() {
        // We've beeen disconnected, so reset our Promise that reflects this state.
        this._canResolveUrls = new Promise((resolved) => {
            this._connectedResolver = resolved;
        });
    }

    isTargetedorPopFunds(data) {
        this._isTargetedorPopFunds = data;
           
        if ( this._isTargetedorPopFunds === 'LB2BPointofPurchase' || SalesRepCA) {
            this.isFgTargetedFunds = false;
        } else {
            this.isFgTargetedFunds = true;
        }
    }

    /**
     * Handler for the 'click' event fired from 'contents'
     *
     * @param {Object} evt the event object
     */
    handleProductDetailNavigation(evt) {
        evt.preventDefault();
        const productId = evt.target.dataset.productid;
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: productId,
                actionName: 'view'
            }
        });
    }

    /**
     * Fires an event to delete a single cart item
     * @private
     * @param {ClickEvent} clickEvt A click event.
     * @fires Items#singlecartitemdelete
     */

    handleDeleteCartItem(clickEvt) {
        console.log('=====CART ID 1======', clickEvt.target.dataset.cartitemid);
        this.deleteCartItemId = clickEvt.target.dataset.cartitemid;
        this.customFormModal = true;
    }

    customDelete(event) {
        console.log('-----------', event.target.id);
        const cartItemId = this.deleteCartItemId;
        let element = this.template.querySelector(`[data-id = "${cartItemId}"]`).value;
        console.log('=====CART ID 3======', cartItemId);
        let incrementValue;
        let productName;
        let productSku;
        let productBrand;
        let productPrice;
        let productCurrency = this.currencyCode;
        let index;
        for (let i = 0; i <= this._providedItems.length; i++) {
            if (this._providedItems[i].cartItem.cartItemId == cartItemId) {
                productName = this._providedItems[i].cartItem.name;
                productSku = this._providedItems[i].cartItem.productDetails.sku;
                productBrand = this._providedItems[i].cartItem.productDetails.fields.Brand__c;
                productPrice = this._providedItems[i].cartItem.listPrice;
                index = i + 1;
                break;
            }
        }
        element = parseInt(element);

        //this.template.querySelector(`[data-id = "${cartItemId}"]`).value = element;
        const quantity = element;

        removeProductEvent(
            'remove_from_cart',
            productName,
            productBrand,
            productSku,
            null,
            productPrice,
            null,
            productCurrency,
            index,
            quantity
        );

        this.dispatchEvent(
            new CustomEvent(SINGLE_CART_ITEM_DELETE, {
                bubbles: true,
                composed: true,
                cancelable: false,
                detail: {
                    cartItemId
                }
            })
        );
        this.customFormModal = false;
        //window.location.reload(); //refresh the page after deleting the data
    }

    /**
     * Handles a click event on the input element.
     *
     * @param {ClickEvent} clickEvent
     *  A click event.
     */

    handleQuantityInSelectorClick(clickEvent) {
        const cartItemId = clickEvent.target.dataset.itemId;
        let element = this.template.querySelector(`[data-id = "${cartItemId}"]`).value;

        let incrementValue;
        let productName;
        let productSku;
        let productBrand;
        let productPrice;
        let productCurrency = this.currencyCode;
        let index;
        for (let i = 0; i <= this._providedItems.length; i++) {
            if (this._providedItems[i].cartItem.cartItemId == cartItemId) {
                incrementValue = this._providedItems[i].cartItem.inc;
                productName = this._providedItems[i].cartItem.name;
                productSku = this._providedItems[i].cartItem.productDetails.sku;
                productBrand = this._providedItems[i].cartItem.productDetails.fields.Brand__c;
                productPrice = this._providedItems[i].cartItem.listPrice;
                index = i + 1;
                break;
            }
        }
        element = parseInt(element) + parseInt(incrementValue);

        //this.template.querySelector(`[data-id = "${cartItemId}"]`).value = element;
        const quantity = element;

        let qtyMin;
        let qtyInc;
        let qtyMax;
        for (let i = 0; i <= this._providedItems.length; i++) {
            if (this._providedItems[i].cartItem.cartItemId == cartItemId) {
                qtyMin = this._providedItems[i].cartItem.min;
                qtyInc = this._providedItems[i].cartItem.inc;
                qtyMax = this._providedItems[i].cartItem.max;
                break;
            }
        }
        addtocartEvent(
            'add_to_cart',
            productName,
            productBrand,
            productSku,
            null,
            productPrice,
            null,
            productCurrency,
            index,
            incrementValue
        );

        // Fire a new event with extra data.
        this.dispatchEvent(
            new CustomEvent(QUANTITY_CHANGED_EVT, {
                bubbles: true,
                composed: true,
                cancelable: false,
                detail: {
                    cartItemId,
                    quantity,
                    qtyMin,
                    qtyInc,
                    qtyMax
                }
            })
        );
    }

    handleQuantityDeSelectorClick(clickEvent) {
        const cartItemId = clickEvent.target.dataset.itemId;
        let element = this.template.querySelector(`[data-id = "${cartItemId}"]`).value;
        let productName;
        let productSku;
        let productBrand;
        let productPrice;
        let productCurrency = this.currencyCode;
        let index;
        let incrementValue;
        if (element > 1) {
            for (let i = 0; i <= this._providedItems.length; i++) {
                if (this._providedItems[i].cartItem.cartItemId == cartItemId) {
                    incrementValue = this._providedItems[i].cartItem.inc;
                    productName = this._providedItems[i].cartItem.name;
                    productSku = this._providedItems[i].cartItem.productDetails.sku;
                    productBrand = this._providedItems[i].cartItem.productDetails.fields.Brand__c;
                    productPrice = this._providedItems[i].cartItem.listPrice;
                    index = i + 1;
                    break;
                }
            }
            element = parseInt(element) - parseInt(incrementValue);
        }

        // this.template.querySelector(`[data-id = "${cartItemId}"]`).value = element;
        const quantity = element;

        let qtyMin;
        let qtyInc;
        let qtyMax;
        for (let i = 0; i <= this._providedItems.length; i++) {
            if (this._providedItems[i].cartItem.cartItemId == cartItemId) {
                qtyMin = this._providedItems[i].cartItem.min;
                qtyInc = this._providedItems[i].cartItem.inc;
                qtyMax = this._providedItems[i].cartItem.max;
                break;
            }
        }
        removeProductEvent(
            'remove_from_cart',
            productName,
            productBrand,
            productSku,
            null,
            productPrice,
            null,
            productCurrency,
            index,
            incrementValue
        );

        // Fire a new event with extra data.
        this.dispatchEvent(
            new CustomEvent(QUANTITY_CHANGED_EVT, {
                bubbles: true,
                composed: true,
                cancelable: false,
                detail: {
                    cartItemId,
                    quantity,
                    qtyMin,
                    qtyInc,
                    qtyMax
                }
            })
        ).catch((error) => {
            this.error = error;
            console.log('Errors: ' + JSON.stringify(error));

            let message = error.body.message;

            this.dispatchEvent(
                new ShowToastEvent({
                    title: this.label.LB2BErrorDetected,
                    message: message,
                    variant: 'error'
                })
            );
        });
    }

    handleQuantitySelectorClick(clickEvent) {
        const cartItemId = clickEvent.target.dataset.itemId;
        let element = this.template.querySelector(`[data-id = "${cartItemId}"]`).value;
        const quantity = element;

        let searchCmp = this.template.querySelector(`[data-id = "${cartItemId}"]`);
        let searchvalue = searchCmp.value;

        if (searchvalue <= 0) {
            searchCmp.setCustomValidity('Minimum Qty is 1');
        } else {
            searchCmp.setCustomValidity(''); // clear previous value
        }
        searchCmp.reportValidity();

        let qtyMin;
        let qtyInc;
        let qtyMax;
        for (let i = 0; i <= this._providedItems.length; i++) {
            if (this._providedItems[i].cartItem.cartItemId == cartItemId) {
                qtyMin = this._providedItems[i].cartItem.min;
                qtyInc = this._providedItems[i].cartItem.inc;
                qtyMax = this._providedItems[i].cartItem.max;
                break;
            }
        }
        // Fire a new event with extra data.
        this.dispatchEvent(
            new CustomEvent(QUANTITY_CHANGED_EVT, {
                bubbles: true,
                composed: true,
                cancelable: false,
                detail: {
                    cartItemId,
                    quantity,
                    qtyMin,
                    qtyInc,
                    qtyMax
                }
            })
        );
    }

    handleWorkFlowIdchange(event) {
        //*********ommenting following line SD */
        // this.isLoading = true;
        let cartItemId = event.target.dataset.itemId;
        let workflowid = event.target.value;
        console.log('cart itemId:', cartItemId, workflowid);
        this.updateWorkFlowId(cartItemId, workflowid);
        fireEvent(this.pageRef, 'isLineLevelWorkFlowId', workflowid);
    }

    updateWorkFlowId(cartItemId, workflowid) {
        console.log('cart itemId updateworkflow:', cartItemId, workflowid);
        let fields = {};
        fields[ID_FIELD.fieldApiName] = cartItemId;
        fields[ITEMWORKFLOW_ID.fieldApiName] = workflowid;

        const recordInput = { fields: fields };
        console.log('record input', recordInput);
        updateRecord(recordInput)
            .then((result) => {
                console.log('resulttttt', result);
            })
            .catch((error) => {
                console.log('error', error);
            });
    }
    // Getter
    get hasInternalAccess() {
        return hasPermission;
    }

    @track mapData= [];
    mapDataFinal = [];
    PushToDataLayer(){
        let productCurrency = this.currencyCode;
        for (var i = 0; i < this._providedItems.length; i++) {
            this.mapData.push(
                {
                    'item_name' : this._providedItems[i].cartItem.name,
                    'item_brand' : this._providedItems[i].cartItem.productDetails.fields.Brand__c,
                    'item_id' : this._providedItems[i].cartItem.productDetails.sku,
                    'item_variant' : null,
                    'discount' : null,
                    'currency' : productCurrency,
                    'quantity': this._providedItems[i].cartItem.quantity,
                    'index' : i+1
                }); 
        }
        this.mapDataFinal = this.mapData;
        console.log('Final Array ', JSON.parse(JSON.stringify(this.mapDataFinal)));
        dispatchUpdateDataLayerEvent({
            'event': 'view_cart',
            'ecommerce': {
             'items': JSON.parse(JSON.stringify(this.mapDataFinal))
            }
       })
    }
}

export function dispatchUpdateDataLayerEvent(detail) {
    console.log('View Cart ',detail);
     document.dispatchEvent(
     new CustomEvent('updatedatalayer', {
     detail
     })
     );
 }